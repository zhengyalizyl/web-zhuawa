function helloWorld(sth) {
    return 'helloworld zhaowa' + sth;
}
console.log(helloWorld('ts'));
