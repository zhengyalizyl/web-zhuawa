function helloWorld(sth: string) {
    return 'helloworld zhaowa' + sth;
}
console.log(helloWorld('ts'));