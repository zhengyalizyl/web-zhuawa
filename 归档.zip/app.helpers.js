import { apps } from './app.js'
//app status
export const NOT_LOADED = 'NOT_LOADED'; //没有被加载
export const LOADING_SOURCE_CODE = 'LOADING_SOURCE_CODE'; // 路径匹配了，要加载这个资源
export const LOAD_ERROR = 'LOAD_ERROR'; // 资源加载失败

//启动的过程
export const NOT_BOOTSTRAPPED = 'NOT_BOOTSTRAPPED'; // 加载完成，但是还没有启动
export const BOOTSTRAPPING = 'BOOTSTRAPPING'; // 启动中
export const NOT_MOUNTED = 'NOT_MOUNTED'; // 启动完成，但是还没有挂载

//挂载流程
export const MOUNTING = 'MOUNTING'; // 挂载中
export const MOUNTED = 'MOUNTED'; // 挂载完成

//卸载流程
export const UNMOUNTING = 'UNMOUNTING'; // 卸载中

//看一下这个应用是否正在被激活
export const isActive = (app) => {
  return app.status === MOUNTED; // 如果这个应用是挂载状态，那么就是激活的
}

//看一下这个应用是否应该被激活
export const shouldBeActive = (app) => {
  return app.activeWhen(window.location);
}

//加载正在下载应用LOADING_SOURCE_CODE,激活已经运行了


export const getAppChanges = () => {
  const appsToLoad = [];
  const appsToMount = [];
  const appsToUnmount = [];
  console.log(apps,'---apss')
  apps.forEach(app => {
    let appShouldBeActive = shouldBeActive(app);
    switch (app.status) {
      case NOT_LOADED:
      case LOADING_SOURCE_CODE:
        //1）标记当前路径下 哪些应用被加载
        if (appShouldBeActive) {
          appsToLoad.push(app);
        }
        break;
      case NOT_BOOTSTRAPPED:
      case BOOTSTRAPPING:
      case NOT_MOUNTED:
        // 2）当前路径下，哪些应用应该被挂载
        if (appShouldBeActive) {
          appsToMount.push(app);
        }
        break;
      case MOUNTED:
        // 3）当前路径下，哪些应用应该被卸载
        if (!appShouldBeActive) {
          appsToUnmount.push(app);
        }
        break;
     default:
      break;
    }
  })
  return {
    appsToLoad,
    appsToMount,
    appsToUnmount
  }
}