import { reroute } from './reroute.js'

//对用户的路径切换进行劫持，劫持后重新调用reroute方法，进行计算应用的加载
function urlRoute() {
  console.log('urlRoute', arguments)
  reroute(arguments)
}

window.addEventListener('hashchange', urlRoute)
window.addEventListener('popstate', urlRoute)

const capturedEventListeners = {
  hashchange: [],
  popstate: []
}
const listeningTo = ["hashchange", "postate"]

const origianlAddEventListener = window.addEventListener
const originalRemoveEventListener = window.removeEventListener

// export function addEventListener(type,handler){
//   return capturedEventListeners[type].push(handler)
// }

// export function removeEventListener(type,handler){
//   const index = capturedEventListeners[type].indexOf(handler)
//   capturedEventListeners[type].splice(index,1)
// }

window.addEventListener = function (eventName, handler) {
  //有要监听的事件，函数不能重复
  if (listeningTo.indexOf(eventName) > -1 && !capturedEventListeners[eventName].some(listener => listener === callback)) {

    capturedEventListeners[eventName].push(handler);
    return
  }

  return origianlAddEventListener.apply(this, arguments)
}
window.removeEventListener = function (eventName, handler) {
  //有要监听的事件，函数不能重复
  if (listeningTo.indexOf(eventName) > -1 && !capturedEventListeners[eventName].filter(listener => listener !== callback)) {

    capturedEventListeners[eventName].push(handler)
    return
  }

  return originalRemoveEventListener.apply(this, arguments)
}


export function callCapturedEventListeners(e) {
  if (e) {
    const eventType = e[0].type;
    if (listeningTo.indexOf(eventType) > -1) {
      capturedEventListeners[eventType].forEach(listener => listener.apply(this, e))
    }
  }
}

function patchFn(updatedState, methodName) {
  return function () {
    const urlbefore = window.location.href;
    const r = updatedState.apply(this, arguments);
    const urlAfter = window.location.href;
    if (urlbefore !== urlAfter) {
      window.dispatchEvent(new PopStateEvent('popstate'))

    }
    return r
  }
}

window.history.pushState = patchFn(window.history.pushState, 'pushState')

window.history.replaceState = patchFn(window.history.replaceState, 'replaceState')
