import { MOUNTED,UNMOUNTING,NOT_MOUNTED } from "./app.helpers.js";

export function toUnmountPromise(app){
  return Promise.resolve().then(()=>{
    if(app.status !== MOUNTED){
        return app;
    }
    app.status = UNMOUNTING;

    //app.unmount
    return app.unmount(app.customProps).then(()=>{
      app.status = NOT_MOUNTED;
    })
  })
}