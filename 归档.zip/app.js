import { reroute } from "./reroute.js";
import { NOT_LOADED } from "./app.helpers.js";
export let  apps=[];
export function registerApplication(appName, loadApp, activeWhen, customProps){
  const  registration={
    name:appName,
    loadApp,
    activeWhen,
    customProps,
    status:NOT_LOADED,
  }
 apps.push(registration)
 //未加载->加载->挂载->卸载

 //需要检查哪些应用要加载,还有哪些应用被移除，哪些应用要被挂载
 reroute();
}


export  default apps;