import { NOT_LOADED, LOADING_SOURCE_CODE, NOT_BOOTSTRAPPED } from "./app.helpers.js"

function flattenArrayToPromise(fns){
  const arr = Array.isArray(fns) ? fns : [fns];
  return function(props){
    return arr.reduce((rPromise,fn)=>rPromise.then(()=>fn(props)),Promise.resolve());
  }
}

export const toLoadPromise = (app) => {
  return Promise.resolve().then(() => {
    if (app.status !== NOT_LOADED) {
      return app
    }
    app.status = LOADING_SOURCE_CODE;//正在加载应用
    const temp = app.loadApp(app.customProps).then((v) => {
      const { bootstrap, mount, unmount } = v;
      app.status = NOT_BOOTSTRAPPED;
      app.bootstrap = flattenArrayToPromise(bootstrap);
      app.mount = flattenArrayToPromise(mount);
      app.unmount = flattenArrayToPromise(unmount);
      console.log(app,'-----toLoadPromise')
      return app
    });

    return temp
  })
}