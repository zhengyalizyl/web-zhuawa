import { getAppChanges, shouldBeActive } from "./app.helpers.js";
import { toLoadPromise } from './load.js'
import { started } from "./start.js";
import {toUnmountPromise} from './unmount.js'
import { toBootstrapPromise} from "./bootstrap.js";
import { toMountPromise } from "./mount.js";
import { callCapturedEventListeners} from './navigation-event.js'

let appChangeUnderway=false;
let peopleWaitingOnAppChange=[];
// 后续路径变化,也需要走这里，重新计算哪些应用被加载或者卸载
export const reroute = (event) => {
  if(appChangeUnderway){
    return new Promise((resolve,reject)=>{
      peopleWaitingOnAppChange.push({
        resolve,
        reject
      })
    })
  }
  const { appsToLoad, appsToUnmount, appsToMount } = getAppChanges();

  if(started){
    appChangeUnderway=true;
    return  performAppChange(appsToUnmount,appsToLoad,appsToMount,event);
  }
  //加载完毕后，需要去挂载应用
  return loadApps(appsToLoad);
}

export const loadApps=(appsToLoad=[])=>{
  //应用的加载
  console.log(appsToLoad,'appsToLoad')
 return Promise.all(appsToLoad.map(toLoadPromise)).then(callEventListener) // 目前没有调用start
}

export const performAppChange=(appsToUnmount=[],appsToLoad=[],appsToMount=[],event)=>{
  //将不需要的应用卸载掉
  const unmountAllPromise= Promise.all(appsToUnmount.map(toUnmountPromise))

  //加载需要的应用 ->启动对应的应用->卸载对应的应用

  //2）加载需要的应用（可能这个应用在注册的时候已经被加载了）
  const loadMountPormises= Promise.all(appsToLoad.map((app)=>toLoadPromise(app).then((app)=>{
    //当应用加载完毕后，需要启动和挂载，但是要保证挂载前，先卸载掉对应的应用
    return tryBootStrapAndMount(app,unmountAllPromise)
  })))
  //如果应用 没有加载，需要先加载，再启动，再挂载
  const mountPormises= Promise.all(appsToMount.map((app)=> tryBootStrapAndMount(app,unmountAllPromise)))
  return Promise.all([loadMountPormises,mountPormises]).then(()=>{
     callEventListener(event);
     appChangeUnderway=false;
     if(peopleWaitingOnAppChange.length>0){
       peopleWaitingOnAppChange=[];
     }
  })
}

export const tryBootStrapAndMount=(app,unmountAllPromise)=>{
  //启动应用
  if(shouldBeActive(app)){
    //保证卸载完毕再挂载
    return toBootstrapPromise(app).then(app=>unmountAllPromise.then(()=>{
      return toMountPromise(app)
    }))
  }

}

export const callEventListener=(event)=>{
  callCapturedEventListeners(event);
}