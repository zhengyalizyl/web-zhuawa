import { reroute } from "./reroute.js";

export let started = false
export function start(){
 started = true;//用户启动了
 reroute()//启动路由

}