import{i as ze,q as wn,w as He,a6 as Sn,d as te,h as d,f as M,a7 as kt,a8 as kn,j as Pe,e as I,g as dt,p as Ge,U as er,W as Or,t as ie,k as Cn,a9 as Ir,z as tr,l as Bt,aa as Vr,n as at,S as Ct,ab as Rn,A as rr,m as $n,ac as zn,ad as Pn,L as sr,C as vt,H as dr,E as Z,R as mt,u as A,N as Br,D as ae,V as _n,B as Mr,Q as Mt,M as An,F as Tn,Y as cr,$ as Fn,a1 as En,a2 as On,a3 as In,a5 as Vn,G as Bn}from"./TitleBar-Ddy3ec9_.js";import{O as Mn,P as Un,a as p,d as $,c as U,e as C,Q as je,R as jn,u as Xe,h as fe,S as Dn,j as nr,l as Le,p as ue,T as qn,U as ur,V as ar,X as Ln,m as Ut,Y as $e,Z as _e,_ as De,$ as yt,a0 as Ae,a1 as Oe,a2 as Ie,a3 as Ke,a4 as qe,a5 as Ur,a6 as jt,a7 as Dt,a8 as qt,o as Ye,a9 as Ze,z as Rt,y as Lt,aa as it,ab as Nt,ac as Wt,ad as Ht,g as ir,ae as jr,af as Nn,k as Q,ag as Wn,ah as Hn,B as rt,ai as Kn,aj as Gn,ak as Xn,al as Yn,am as Se,an as Zn,ao as Dr,ap as Jn,s as zt,r as Re,aq as Qn,f as fr,ar as Pt,N as ea,as as ta,at as ra,au as _t,av as na,aw as aa,ax as ia,ay as At,az as oa,aA as ft,E as la,aB as qr,aC as Tt,A as pr,aD as hr,H as sa,G as da,F as ca,J as ua,L as fa}from"./useNaiveTheme-BA-XMT0r.js";import{c as br,a as pa,u as ha,h as gr,f as ba,B as ga,V as va,b as ma,d as Kt,e as ya,g as xt,N as xa,i as wa,j as Lr,k as vr,o as Sa,l as wt,S as ka}from"./Scrollbar-CQDm2Mp8.js";function Ca(e,t,r){var n;const a=ze(e,null);if(a===null)return;const i=(n=wn())===null||n===void 0?void 0:n.proxy;He(r,o),o(r.value),Sn(()=>{o(void 0,r.value)});function o(c,u){if(!a)return;const f=a[t];u!==void 0&&l(f,u),c!==void 0&&s(f,c)}function l(c,u){c[u]||(c[u]=[]),c[u].splice(c[u].findIndex(f=>f===i),1)}function s(c,u){c[u]||(c[u]=[]),~c[u].findIndex(f=>f===i)||c[u].push(i)}}const Ra=br(".v-x-scroll",{overflow:"auto",scrollbarWidth:"none"},[br("&::-webkit-scrollbar",{width:0,height:0})]),$a=te({name:"XScroll",props:{disabled:Boolean,onScroll:Function},setup(){const e=M(null);function t(a){!(a.currentTarget.offsetWidth<a.currentTarget.scrollWidth)||a.deltaY===0||(a.currentTarget.scrollLeft+=a.deltaY+a.deltaX,a.preventDefault())}const r=Mn();return Ra.mount({id:"vueuc/x-scroll",head:!0,anchorMetaName:pa,ssr:r}),Object.assign({selfRef:e,handleWheel:t},{scrollTo(...a){var i;(i=e.value)===null||i===void 0||i.scrollTo(...a)}})},render(){return d("div",{ref:"selfRef",onScroll:this.onScroll,onWheel:this.disabled?void 0:this.handleWheel,class:"v-x-scroll"},this.$slots)}}),za={tiny:"mini",small:"tiny",medium:"small",large:"medium",huge:"large"};function Pa(e){const t=za[e];if(t===void 0)throw new Error(`${e} has no smaller size.`);return t}function _a(e,t="default",r=[]){const a=e.$slots[t];return a===void 0?r:a()}function mr(e){return Object.keys(e)}var Aa=/\s/;function Ta(e){for(var t=e.length;t--&&Aa.test(e.charAt(t)););return t}var Fa=/^\s+/;function Ea(e){return e&&e.slice(0,Ta(e)+1).replace(Fa,"")}var yr=NaN,Oa=/^[-+]0x[0-9a-f]+$/i,Ia=/^0b[01]+$/i,Va=/^0o[0-7]+$/i,Ba=parseInt;function xr(e){if(typeof e=="number")return e;if(Un(e))return yr;if(kt(e)){var t=typeof e.valueOf=="function"?e.valueOf():e;e=kt(t)?t+"":t}if(typeof e!="string")return e===0?e:+e;e=Ea(e);var r=Ia.test(e);return r||Va.test(e)?Ba(e.slice(2),r?2:8):Oa.test(e)?yr:+e}var Ft=function(){return kn.Date.now()},Ma="Expected a function",Ua=Math.max,ja=Math.min;function Da(e,t,r){var n,a,i,o,l,s,c=0,u=!1,f=!1,x=!0;if(typeof e!="function")throw new TypeError(Ma);t=xr(t)||0,kt(r)&&(u=!!r.leading,f="maxWait"in r,i=f?Ua(xr(r.maxWait)||0,t):i,x="trailing"in r?!!r.trailing:x);function S(k){var V=n,_=a;return n=a=void 0,c=k,o=e.apply(_,V),o}function v(k){return c=k,l=setTimeout(b,t),u?S(k):o}function m(k){var V=k-s,_=k-c,O=t-V;return f?ja(O,i-_):O}function y(k){var V=k-s,_=k-c;return s===void 0||V>=t||V<0||f&&_>=i}function b(){var k=Ft();if(y(k))return T(k);l=setTimeout(b,m(k))}function T(k){return l=void 0,x&&n?S(k):(n=a=void 0,o)}function R(){l!==void 0&&clearTimeout(l),c=0,n=s=a=l=void 0}function P(){return l===void 0?o:T(Ft())}function F(){var k=Ft(),V=y(k);if(n=arguments,a=this,s=k,V){if(l===void 0)return v(s);if(f)return clearTimeout(l),l=setTimeout(b,t),S(s)}return l===void 0&&(l=setTimeout(b,t)),o}return F.cancel=R,F.flush=P,F}var qa="Expected a function";function La(e,t,r){var n=!0,a=!0;if(typeof e!="function")throw new TypeError(qa);return kt(r)&&(n="leading"in r?!!r.leading:n,a="trailing"in r?!!r.trailing:a),Da(e,t,{leading:n,maxWait:t,trailing:a})}const Nr=te({name:"Add",render(){return d("svg",{width:"512",height:"512",viewBox:"0 0 512 512",fill:"none",xmlns:"http://www.w3.org/2000/svg"},d("path",{d:"M256 112V400M400 256H112",stroke:"currentColor","stroke-width":"32","stroke-linecap":"round","stroke-linejoin":"round"}))}}),Na=te({name:"ChevronLeft",render(){return d("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},d("path",{d:"M10.3536 3.14645C10.5488 3.34171 10.5488 3.65829 10.3536 3.85355L6.20711 8L10.3536 12.1464C10.5488 12.3417 10.5488 12.6583 10.3536 12.8536C10.1583 13.0488 9.84171 13.0488 9.64645 12.8536L5.14645 8.35355C4.95118 8.15829 4.95118 7.84171 5.14645 7.64645L9.64645 3.14645C9.84171 2.95118 10.1583 2.95118 10.3536 3.14645Z",fill:"currentColor"}))}}),Wa=te({name:"ChevronRight",render(){return d("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},d("path",{d:"M5.64645 3.14645C5.45118 3.34171 5.45118 3.65829 5.64645 3.85355L9.79289 8L5.64645 12.1464C5.45118 12.3417 5.45118 12.6583 5.64645 12.8536C5.84171 13.0488 6.15829 13.0488 6.35355 12.8536L10.8536 8.35355C11.0488 8.15829 11.0488 7.84171 10.8536 7.64645L6.35355 3.14645C6.15829 2.95118 5.84171 2.95118 5.64645 3.14645Z",fill:"currentColor"}))}}),Ha=p("collapse","width: 100%;",[p("collapse-item",`
 font-size: var(--n-font-size);
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 margin: var(--n-item-margin);
 `,[$("disabled",[C("header","cursor: not-allowed;",[C("header-main",`
 color: var(--n-title-text-color-disabled);
 `),p("collapse-item-arrow",`
 color: var(--n-arrow-color-disabled);
 `)])]),p("collapse-item","margin-left: 32px;"),U("&:first-child","margin-top: 0;"),U("&:first-child >",[C("header","padding-top: 0;")]),$("left-arrow-placement",[C("header",[p("collapse-item-arrow","margin-right: 4px;")])]),$("right-arrow-placement",[C("header",[p("collapse-item-arrow","margin-left: 4px;")])]),C("content-wrapper",[C("content-inner","padding-top: 16px;"),jn({duration:"0.15s"})]),$("active",[C("header",[$("active",[p("collapse-item-arrow","transform: rotate(90deg);")])])]),U("&:not(:first-child)","border-top: 1px solid var(--n-divider-color);"),je("disabled",[$("trigger-area-main",[C("header",[C("header-main","cursor: pointer;"),p("collapse-item-arrow","cursor: default;")])]),$("trigger-area-arrow",[C("header",[p("collapse-item-arrow","cursor: pointer;")])]),$("trigger-area-extra",[C("header",[C("header-extra","cursor: pointer;")])])]),C("header",`
 font-size: var(--n-title-font-size);
 display: flex;
 flex-wrap: nowrap;
 align-items: center;
 transition: color .3s var(--n-bezier);
 position: relative;
 padding: var(--n-title-padding);
 color: var(--n-title-text-color);
 `,[C("header-main",`
 display: flex;
 flex-wrap: nowrap;
 align-items: center;
 font-weight: var(--n-title-font-weight);
 transition: color .3s var(--n-bezier);
 flex: 1;
 color: var(--n-title-text-color);
 `),C("header-extra",`
 display: flex;
 align-items: center;
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 `),p("collapse-item-arrow",`
 display: flex;
 transition:
 transform .15s var(--n-bezier),
 color .3s var(--n-bezier);
 font-size: 18px;
 color: var(--n-arrow-color);
 `)])])]),Ka=Object.assign(Object.assign({},fe.props),{defaultExpandedNames:{type:[Array,String],default:null},expandedNames:[Array,String],arrowPlacement:{type:String,default:"left"},accordion:{type:Boolean,default:!1},displayDirective:{type:String,default:"if"},triggerAreas:{type:Array,default:()=>["main","extra","arrow"]},onItemHeaderClick:[Function,Array],"onUpdate:expandedNames":[Function,Array],onUpdateExpandedNames:[Function,Array],onExpandedNamesChange:{type:[Function,Array],validator:()=>!0,default:void 0}}),Wr=dt("n-collapse"),Ga=te({name:"Collapse",props:Ka,slots:Object,setup(e,{slots:t}){const{mergedClsPrefixRef:r,inlineThemeDisabled:n,mergedRtlRef:a}=Pe(e),i=M(e.defaultExpandedNames),o=I(()=>e.expandedNames),l=Xe(o,i),s=fe("Collapse","-collapse",Ha,Dn,e,r);function c(m){const{"onUpdate:expandedNames":y,onUpdateExpandedNames:b,onExpandedNamesChange:T}=e;b&&ue(b,m),y&&ue(y,m),T&&ue(T,m),i.value=m}function u(m){const{onItemHeaderClick:y}=e;y&&ue(y,m)}function f(m,y,b){const{accordion:T}=e,{value:R}=l;if(T)m?(c([y]),u({name:y,expanded:!0,event:b})):(c([]),u({name:y,expanded:!1,event:b}));else if(!Array.isArray(R))c([y]),u({name:y,expanded:!0,event:b});else{const P=R.slice(),F=P.findIndex(k=>y===k);~F?(P.splice(F,1),c(P),u({name:y,expanded:!1,event:b})):(P.push(y),c(P),u({name:y,expanded:!0,event:b}))}}Ge(Wr,{props:e,mergedClsPrefixRef:r,expandedNamesRef:l,slots:t,toggleItem:f});const x=nr("Collapse",a,r),S=I(()=>{const{common:{cubicBezierEaseInOut:m},self:{titleFontWeight:y,dividerColor:b,titlePadding:T,titleTextColor:R,titleTextColorDisabled:P,textColor:F,arrowColor:k,fontSize:V,titleFontSize:_,arrowColorDisabled:O,itemMargin:N}}=s.value;return{"--n-font-size":V,"--n-bezier":m,"--n-text-color":F,"--n-divider-color":b,"--n-title-padding":T,"--n-title-font-size":_,"--n-title-text-color":R,"--n-title-text-color-disabled":P,"--n-title-font-weight":y,"--n-arrow-color":k,"--n-arrow-color-disabled":O,"--n-item-margin":N}}),v=n?Le("collapse",void 0,S,e):void 0;return{rtlEnabled:x,mergedTheme:s,mergedClsPrefix:r,cssVars:n?void 0:S,themeClass:v?.themeClass,onRender:v?.onRender}},render(){var e;return(e=this.onRender)===null||e===void 0||e.call(this),d("div",{class:[`${this.mergedClsPrefix}-collapse`,this.rtlEnabled&&`${this.mergedClsPrefix}-collapse--rtl`,this.themeClass],style:this.cssVars},this.$slots)}}),Xa=te({name:"CollapseItemContent",props:{displayDirective:{type:String,required:!0},show:Boolean,clsPrefix:{type:String,required:!0}},setup(e){return{onceTrue:ha(ie(e,"show"))}},render(){return d(qn,null,{default:()=>{const{show:e,displayDirective:t,onceTrue:r,clsPrefix:n}=this,a=t==="show"&&r,i=d("div",{class:`${n}-collapse-item__content-wrapper`},d("div",{class:`${n}-collapse-item__content-inner`},this.$slots));return a?er(i,[[Or,e]]):e?i:null}})}}),Ya={title:String,name:[String,Number],disabled:Boolean,displayDirective:String},Za=te({name:"CollapseItem",props:Ya,setup(e){const{mergedRtlRef:t}=Pe(e),r=Ut(),n=Cn(()=>{var f;return(f=e.name)!==null&&f!==void 0?f:r}),a=ze(Wr);a||Ir("collapse-item","`n-collapse-item` must be placed inside `n-collapse`.");const{expandedNamesRef:i,props:o,mergedClsPrefixRef:l,slots:s}=a,c=I(()=>{const{value:f}=i;if(Array.isArray(f)){const{value:x}=n;return!~f.findIndex(S=>S===x)}else if(f){const{value:x}=n;return x!==f}return!0});return{rtlEnabled:nr("Collapse",t,l),collapseSlots:s,randomName:r,mergedClsPrefix:l,collapsed:c,triggerAreas:ie(o,"triggerAreas"),mergedDisplayDirective:I(()=>{const{displayDirective:f}=e;return f||o.displayDirective}),arrowPlacement:I(()=>o.arrowPlacement),handleClick(f){let x="main";gr(f,"arrow")&&(x="arrow"),gr(f,"extra")&&(x="extra"),o.triggerAreas.includes(x)&&a&&!e.disabled&&a.toggleItem(c.value,n.value,f)}}},render(){const{collapseSlots:e,$slots:t,arrowPlacement:r,collapsed:n,mergedDisplayDirective:a,mergedClsPrefix:i,disabled:o,triggerAreas:l}=this,s=ur(t.header,{collapsed:n},()=>[this.title]),c=t["header-extra"]||e["header-extra"],u=t.arrow||e.arrow;return d("div",{class:[`${i}-collapse-item`,`${i}-collapse-item--${r}-arrow-placement`,o&&`${i}-collapse-item--disabled`,!n&&`${i}-collapse-item--active`,l.map(f=>`${i}-collapse-item--trigger-area-${f}`)]},d("div",{class:[`${i}-collapse-item__header`,!n&&`${i}-collapse-item__header--active`]},d("div",{class:`${i}-collapse-item__header-main`,onClick:this.handleClick},r==="right"&&s,d("div",{class:`${i}-collapse-item-arrow`,key:this.rtlEnabled?0:1,"data-arrow":!0},ur(u,{collapsed:n},()=>[d(ar,{clsPrefix:i},{default:()=>this.rtlEnabled?d(Na,null):d(Wa,null)})])),r==="left"&&s),Ln(c,{collapsed:n},f=>d("div",{class:`${i}-collapse-item__header-extra`,onClick:this.handleClick,"data-extra":!0},f))),d(Xa,{clsPrefix:i,displayDirective:a,show:!n},t))}});function Ja(e,t){switch(e[0]){case"hex":return t?"#000000FF":"#000000";case"rgb":return t?"rgba(0, 0, 0, 1)":"rgb(0, 0, 0)";case"hsl":return t?"hsla(0, 0%, 0%, 1)":"hsl(0, 0%, 0%)";case"hsv":return t?"hsva(0, 0%, 0%, 1)":"hsv(0, 0%, 0%)"}return"#000000"}function lt(e){return e===null?null:/^ *#/.test(e)?"hex":e.includes("rgb")?"rgb":e.includes("hsl")?"hsl":e.includes("hsv")?"hsv":null}function Qa(e,t=[255,255,255],r="AA"){const[n,a,i,o]=$e(_e(e));if(o===1){const S=pt([n,a,i]),v=pt(t);return(Math.max(S,v)+.05)/(Math.min(S,v)+.05)>=(r==="AA"?4.5:7)}const l=Math.round(n*o+t[0]*(1-o)),s=Math.round(a*o+t[1]*(1-o)),c=Math.round(i*o+t[2]*(1-o)),u=pt([l,s,c]),f=pt(t);return(Math.max(u,f)+.05)/(Math.min(u,f)+.05)>=(r==="AA"?4.5:7)}function pt(e){const[t,r,n]=e.map(a=>(a/=255,a<=.03928?a/12.92:Math.pow((a+.055)/1.055,2.4)));return .2126*t+.7152*r+.0722*n}function ei(e){return e=Math.round(e),e>=360?359:e<0?0:e}function ti(e){return e=Math.round(e*100)/100,e>1?1:e<0?0:e}const ri={rgb:{hex(e){return Ie($e(e))},hsl(e){const[t,r,n,a]=$e(e);return _e([...qt(t,r,n),a])},hsv(e){const[t,r,n,a]=$e(e);return qe([...Dt(t,r,n),a])}},hex:{rgb(e){return Ae($e(e))},hsl(e){const[t,r,n,a]=$e(e);return _e([...qt(t,r,n),a])},hsv(e){const[t,r,n,a]=$e(e);return qe([...Dt(t,r,n),a])}},hsl:{hex(e){const[t,r,n,a]=Ke(e);return Ie([...jt(t,r,n),a])},rgb(e){const[t,r,n,a]=Ke(e);return Ae([...jt(t,r,n),a])},hsv(e){const[t,r,n,a]=Ke(e);return qe([...Ur(t,r,n),a])}},hsv:{hex(e){const[t,r,n,a]=De(e);return Ie([...Oe(t,r,n),a])},rgb(e){const[t,r,n,a]=De(e);return Ae([...Oe(t,r,n),a])},hsl(e){const[t,r,n,a]=De(e);return _e([...yt(t,r,n),a])}}};function Hr(e,t,r){return r=r||lt(e),r?r===t?e:ri[r][t](e):null}const Qe="12px",ni=12,Be="6px",ai=te({name:"AlphaSlider",props:{clsPrefix:{type:String,required:!0},rgba:{type:Array,default:null},alpha:{type:Number,default:0},onUpdateAlpha:{type:Function,required:!0},onComplete:Function},setup(e){const t=M(null);function r(i){!t.value||!e.rgba||(Ye("mousemove",document,n),Ye("mouseup",document,a),n(i))}function n(i){const{value:o}=t;if(!o)return;const{width:l,left:s}=o.getBoundingClientRect(),c=(i.clientX-s)/(l-ni);e.onUpdateAlpha(ti(c))}function a(){var i;Ze("mousemove",document,n),Ze("mouseup",document,a),(i=e.onComplete)===null||i===void 0||i.call(e)}return{railRef:t,railBackgroundImage:I(()=>{const{rgba:i}=e;return i?`linear-gradient(to right, rgba(${i[0]}, ${i[1]}, ${i[2]}, 0) 0%, rgba(${i[0]}, ${i[1]}, ${i[2]}, 1) 100%)`:""}),handleMouseDown:r}},render(){const{clsPrefix:e}=this;return d("div",{class:`${e}-color-picker-slider`,ref:"railRef",style:{height:Qe,borderRadius:Be},onMousedown:this.handleMouseDown},d("div",{style:{borderRadius:Be,position:"absolute",left:0,right:0,top:0,bottom:0,overflow:"hidden"}},d("div",{class:`${e}-color-picker-checkboard`}),d("div",{class:`${e}-color-picker-slider__image`,style:{backgroundImage:this.railBackgroundImage}})),this.rgba&&d("div",{style:{position:"absolute",left:Be,right:Be,top:0,bottom:0}},d("div",{class:`${e}-color-picker-handle`,style:{left:`calc(${this.alpha*100}% - ${Be})`,borderRadius:Be,width:Qe,height:Qe}},d("div",{class:`${e}-color-picker-handle__fill`,style:{backgroundColor:Ae(this.rgba),borderRadius:Be,width:Qe,height:Qe}}))))}}),or=dt("n-color-picker");function ii(e){return/^\d{1,3}\.?\d*$/.test(e.trim())?Math.max(0,Math.min(Number.parseInt(e),255)):!1}function oi(e){return/^\d{1,3}\.?\d*$/.test(e.trim())?Math.max(0,Math.min(Number.parseInt(e),360)):!1}function li(e){return/^\d{1,3}\.?\d*$/.test(e.trim())?Math.max(0,Math.min(Number.parseInt(e),100)):!1}function si(e){const t=e.trim();return/^#[0-9a-fA-F]+$/.test(t)?[4,5,7,9].includes(t.length):!1}function di(e){return/^\d{1,3}\.?\d*%$/.test(e.trim())?Math.max(0,Math.min(Number.parseInt(e)/100,100)):!1}const ci={paddingSmall:"0 4px"},wr=te({name:"ColorInputUnit",props:{label:{type:String,required:!0},value:{type:[Number,String],default:null},showAlpha:Boolean,onUpdateValue:{type:Function,required:!0}},setup(e){const t=M(""),{themeRef:r}=ze(or,null);tr(()=>{t.value=n()});function n(){const{value:o}=e;if(o===null)return"";const{label:l}=e;return l==="HEX"?o:l==="A"?`${Math.floor(o*100)}%`:String(Math.floor(o))}function a(o){t.value=o}function i(o){let l,s;switch(e.label){case"HEX":s=si(o),s&&e.onUpdateValue(o),t.value=n();break;case"H":l=oi(o),l===!1?t.value=n():e.onUpdateValue(l);break;case"S":case"L":case"V":l=li(o),l===!1?t.value=n():e.onUpdateValue(l);break;case"A":l=di(o),l===!1?t.value=n():e.onUpdateValue(l);break;case"R":case"G":case"B":l=ii(o),l===!1?t.value=n():e.onUpdateValue(l);break}}return{mergedTheme:r,inputValue:t,handleInputChange:i,handleInputUpdateValue:a}},render(){const{mergedTheme:e}=this;return d(Rt,{size:"small",placeholder:this.label,theme:e.peers.Input,themeOverrides:e.peerOverrides.Input,builtinThemeOverrides:ci,value:this.inputValue,onUpdateValue:this.handleInputUpdateValue,onChange:this.handleInputChange,style:this.label==="A"?"flex-grow: 1.25;":""})}}),ui=te({name:"ColorInput",props:{clsPrefix:{type:String,required:!0},mode:{type:String,required:!0},modes:{type:Array,required:!0},showAlpha:{type:Boolean,required:!0},value:{type:String,default:null},valueArr:{type:Array,default:null},onUpdateValue:{type:Function,required:!0},onUpdateMode:{type:Function,required:!0}},setup(e){return{handleUnitUpdateValue(t,r){const{showAlpha:n}=e;if(e.mode==="hex"){e.onUpdateValue((n?Ie:it)(r));return}let a;switch(e.valueArr===null?a=[0,0,0,0]:a=Array.from(e.valueArr),e.mode){case"hsv":a[t]=r,e.onUpdateValue((n?qe:Ht)(a));break;case"rgb":a[t]=r,e.onUpdateValue((n?Ae:Wt)(a));break;case"hsl":a[t]=r,e.onUpdateValue((n?_e:Nt)(a));break}}}},render(){const{clsPrefix:e,modes:t}=this;return d("div",{class:`${e}-color-picker-input`},d("div",{class:`${e}-color-picker-input__mode`,onClick:this.onUpdateMode,style:{cursor:t.length===1?"":"pointer"}},this.mode.toUpperCase()+(this.showAlpha?"A":"")),d(Lt,null,{default:()=>{const{mode:r,valueArr:n,showAlpha:a}=this;if(r==="hex"){let i=null;try{i=n===null?null:(a?Ie:it)(n)}catch{}return d(wr,{label:"HEX",showAlpha:a,value:i,onUpdateValue:o=>{this.handleUnitUpdateValue(0,o)}})}return(r+(a?"a":"")).split("").map((i,o)=>d(wr,{label:i.toUpperCase(),value:n===null?null:n[o],onUpdateValue:l=>{this.handleUnitUpdateValue(o,l)}}))}}))}});function fi(e,t){if(t==="hsv"){const[r,n,a,i]=De(e);return Ae([...Oe(r,n,a),i])}return e}function pi(e){const t=document.createElement("canvas").getContext("2d");return t?(t.fillStyle=e,t.fillStyle):"#000000"}const hi=te({name:"ColorPickerSwatches",props:{clsPrefix:{type:String,required:!0},mode:{type:String,required:!0},swatches:{type:Array,required:!0},onUpdateColor:{type:Function,required:!0}},setup(e){const t=I(()=>e.swatches.map(i=>{const o=lt(i);return{value:i,mode:o,legalValue:fi(i,o)}}));function r(i){const{mode:o}=e;let{value:l,mode:s}=i;return s||(s="hex",/^[a-zA-Z]+$/.test(l)?l=pi(l):(Bt("color-picker",`color ${l} in swatches is invalid.`),l="#000000")),s===o?l:Hr(l,o,s)}function n(i){e.onUpdateColor(r(i))}function a(i,o){i.key==="Enter"&&n(o)}return{parsedSwatchesRef:t,handleSwatchSelect:n,handleSwatchKeyDown:a}},render(){const{clsPrefix:e}=this;return d("div",{class:`${e}-color-picker-swatches`},this.parsedSwatchesRef.map(t=>d("div",{class:`${e}-color-picker-swatch`,tabindex:0,onClick:()=>{this.handleSwatchSelect(t)},onKeydown:r=>{this.handleSwatchKeyDown(r,t)}},d("div",{class:`${e}-color-picker-swatch__fill`,style:{background:t.legalValue}}))))}}),bi=te({name:"ColorPickerTrigger",slots:Object,props:{clsPrefix:{type:String,required:!0},value:{type:String,default:null},hsla:{type:Array,default:null},disabled:Boolean,onClick:Function},setup(e){const{colorPickerSlots:t,renderLabelRef:r}=ze(or,null);return()=>{const{hsla:n,value:a,clsPrefix:i,onClick:o,disabled:l}=e,s=t.label||r.value;return d("div",{class:[`${i}-color-picker-trigger`,l&&`${i}-color-picker-trigger--disabled`],onClick:l?void 0:o},d("div",{class:`${i}-color-picker-trigger__fill`},d("div",{class:`${i}-color-picker-checkboard`}),d("div",{style:{position:"absolute",left:0,right:0,top:0,bottom:0,backgroundColor:n?_e(n):""}}),a&&n?d("div",{class:`${i}-color-picker-trigger__value`,style:{color:Qa(n)?"white":"black"}},s?s(a):a):null))}}}),gi=te({name:"ColorPreview",props:{clsPrefix:{type:String,required:!0},mode:{type:String,required:!0},color:{type:String,default:null,validator:e=>{const t=lt(e);return!!(!e||t&&t!=="hsv")}},onUpdateColor:{type:Function,required:!0}},setup(e){function t(r){var n;const a=r.target.value;(n=e.onUpdateColor)===null||n===void 0||n.call(e,Hr(a.toUpperCase(),e.mode,"hex")),r.stopPropagation()}return{handleChange:t}},render(){const{clsPrefix:e}=this;return d("div",{class:`${e}-color-picker-preview__preview`},d("span",{class:`${e}-color-picker-preview__fill`,style:{background:this.color||"#000000"}}),d("input",{class:`${e}-color-picker-preview__input`,type:"color",value:this.color,onChange:this.handleChange}))}}),Ne="12px",vi=12,Me="6px",mi=6,yi="linear-gradient(90deg,red,#ff0 16.66%,#0f0 33.33%,#0ff 50%,#00f 66.66%,#f0f 83.33%,red)",xi=te({name:"HueSlider",props:{clsPrefix:{type:String,required:!0},hue:{type:Number,required:!0},onUpdateHue:{type:Function,required:!0},onComplete:Function},setup(e){const t=M(null);function r(i){t.value&&(Ye("mousemove",document,n),Ye("mouseup",document,a),n(i))}function n(i){const{value:o}=t;if(!o)return;const{width:l,left:s}=o.getBoundingClientRect(),c=ei((i.clientX-s-mi)/(l-vi)*360);e.onUpdateHue(c)}function a(){var i;Ze("mousemove",document,n),Ze("mouseup",document,a),(i=e.onComplete)===null||i===void 0||i.call(e)}return{railRef:t,handleMouseDown:r}},render(){const{clsPrefix:e}=this;return d("div",{class:`${e}-color-picker-slider`,style:{height:Ne,borderRadius:Me}},d("div",{ref:"railRef",style:{boxShadow:"inset 0 0 2px 0 rgba(0, 0, 0, .24)",boxSizing:"border-box",backgroundImage:yi,height:Ne,borderRadius:Me,position:"relative"},onMousedown:this.handleMouseDown},d("div",{style:{position:"absolute",left:Me,right:Me,top:0,bottom:0}},d("div",{class:`${e}-color-picker-handle`,style:{left:`calc((${this.hue}%) / 359 * 100 - ${Me})`,borderRadius:Me,width:Ne,height:Ne}},d("div",{class:`${e}-color-picker-handle__fill`,style:{backgroundColor:`hsl(${this.hue}, 100%, 50%)`,borderRadius:Me,width:Ne,height:Ne}})))))}}),ht="12px",bt="6px",wi=te({name:"Pallete",props:{clsPrefix:{type:String,required:!0},rgba:{type:Array,default:null},displayedHue:{type:Number,required:!0},displayedSv:{type:Array,required:!0},onUpdateSV:{type:Function,required:!0},onComplete:Function},setup(e){const t=M(null);function r(i){t.value&&(Ye("mousemove",document,n),Ye("mouseup",document,a),n(i))}function n(i){const{value:o}=t;if(!o)return;const{width:l,height:s,left:c,bottom:u}=o.getBoundingClientRect(),f=(u-i.clientY)/s,x=(i.clientX-c)/l,S=100*(x>1?1:x<0?0:x),v=100*(f>1?1:f<0?0:f);e.onUpdateSV(S,v)}function a(){var i;Ze("mousemove",document,n),Ze("mouseup",document,a),(i=e.onComplete)===null||i===void 0||i.call(e)}return{palleteRef:t,handleColor:I(()=>{const{rgba:i}=e;return i?`rgb(${i[0]}, ${i[1]}, ${i[2]})`:""}),handleMouseDown:r}},render(){const{clsPrefix:e}=this;return d("div",{class:`${e}-color-picker-pallete`,onMousedown:this.handleMouseDown,ref:"palleteRef"},d("div",{class:`${e}-color-picker-pallete__layer`,style:{backgroundImage:`linear-gradient(90deg, white, hsl(${this.displayedHue}, 100%, 50%))`}}),d("div",{class:`${e}-color-picker-pallete__layer ${e}-color-picker-pallete__layer--shadowed`,style:{backgroundImage:"linear-gradient(180deg, rgba(0, 0, 0, 0%), rgba(0, 0, 0, 100%))"}}),this.rgba&&d("div",{class:`${e}-color-picker-handle`,style:{width:ht,height:ht,borderRadius:bt,left:`calc(${this.displayedSv[0]}% - ${bt})`,bottom:`calc(${this.displayedSv[1]}% - ${bt})`}},d("div",{class:`${e}-color-picker-handle__fill`,style:{backgroundColor:this.handleColor,borderRadius:bt,width:ht,height:ht}})))}}),Si=U([p("color-picker",`
 display: inline-block;
 box-sizing: border-box;
 height: var(--n-height);
 font-size: var(--n-font-size);
 width: 100%;
 position: relative;
 `),p("color-picker-panel",`
 margin: 4px 0;
 width: 240px;
 font-size: var(--n-panel-font-size);
 color: var(--n-text-color);
 background-color: var(--n-color);
 transition:
 box-shadow .3s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 box-shadow: var(--n-box-shadow);
 `,[ba(),p("input",`
 text-align: center;
 `)]),p("color-picker-checkboard",`
 background: white; 
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `,[U("&::after",`
 background-image: linear-gradient(45deg, #DDD 25%, #0000 25%), linear-gradient(-45deg, #DDD 25%, #0000 25%), linear-gradient(45deg, #0000 75%, #DDD 75%), linear-gradient(-45deg, #0000 75%, #DDD 75%);
 background-size: 12px 12px;
 background-position: 0 0, 0 6px, 6px -6px, -6px 0px;
 background-repeat: repeat;
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),p("color-picker-slider",`
 margin-bottom: 8px;
 position: relative;
 box-sizing: border-box;
 `,[C("image",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `),U("&::after",`
 content: "";
 position: absolute;
 border-radius: inherit;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 box-shadow: inset 0 0 2px 0 rgba(0, 0, 0, .24);
 pointer-events: none;
 `)]),p("color-picker-handle",`
 z-index: 1;
 box-shadow: 0 0 2px 0 rgba(0, 0, 0, .45);
 position: absolute;
 background-color: white;
 overflow: hidden;
 `,[C("fill",`
 box-sizing: border-box;
 border: 2px solid white;
 `)]),p("color-picker-pallete",`
 height: 180px;
 position: relative;
 margin-bottom: 8px;
 cursor: crosshair;
 `,[C("layer",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `,[$("shadowed",`
 box-shadow: inset 0 0 2px 0 rgba(0, 0, 0, .24);
 `)])]),p("color-picker-preview",`
 display: flex;
 `,[C("sliders",`
 flex: 1 0 auto;
 `),C("preview",`
 position: relative;
 height: 30px;
 width: 30px;
 margin: 0 0 8px 6px;
 border-radius: 50%;
 box-shadow: rgba(0, 0, 0, .15) 0px 0px 0px 1px inset;
 overflow: hidden;
 `),C("fill",`
 display: block;
 width: 30px;
 height: 30px;
 `),C("input",`
 position: absolute;
 top: 0;
 left: 0;
 width: 30px;
 height: 30px;
 opacity: 0;
 z-index: 1;
 `)]),p("color-picker-input",`
 display: flex;
 align-items: center;
 `,[p("input",`
 flex-grow: 1;
 flex-basis: 0;
 `),C("mode",`
 width: 72px;
 text-align: center;
 `)]),p("color-picker-control",`
 padding: 12px;
 `),p("color-picker-action",`
 display: flex;
 margin-top: -4px;
 border-top: 1px solid var(--n-divider-color);
 padding: 8px 12px;
 justify-content: flex-end;
 `,[p("button","margin-left: 8px;")]),p("color-picker-trigger",`
 border: var(--n-border);
 height: 100%;
 box-sizing: border-box;
 border-radius: var(--n-border-radius);
 transition: border-color .3s var(--n-bezier);
 cursor: pointer;
 `,[C("value",`
 white-space: nowrap;
 position: relative;
 `),C("fill",`
 border-radius: var(--n-border-radius);
 position: absolute;
 display: flex;
 align-items: center;
 justify-content: center;
 left: 4px;
 right: 4px;
 top: 4px;
 bottom: 4px;
 `),$("disabled","cursor: not-allowed"),p("color-picker-checkboard",`
 border-radius: var(--n-border-radius);
 `,[U("&::after",`
 --n-block-size: calc((var(--n-height) - 8px) / 3);
 background-size: calc(var(--n-block-size) * 2) calc(var(--n-block-size) * 2);
 background-position: 0 0, 0 var(--n-block-size), var(--n-block-size) calc(-1 * var(--n-block-size)), calc(-1 * var(--n-block-size)) 0px; 
 `)])]),p("color-picker-swatches",`
 display: grid;
 grid-gap: 8px;
 flex-wrap: wrap;
 position: relative;
 grid-template-columns: repeat(auto-fill, 18px);
 margin-top: 10px;
 `,[p("color-picker-swatch",`
 width: 18px;
 height: 18px;
 background-image: linear-gradient(45deg, #DDD 25%, #0000 25%), linear-gradient(-45deg, #DDD 25%, #0000 25%), linear-gradient(45deg, #0000 75%, #DDD 75%), linear-gradient(-45deg, #0000 75%, #DDD 75%);
 background-size: 8px 8px;
 background-position: 0px 0, 0px 4px, 4px -4px, -4px 0px;
 background-repeat: repeat;
 `,[C("fill",`
 position: relative;
 width: 100%;
 height: 100%;
 border-radius: 3px;
 box-shadow: rgba(0, 0, 0, .15) 0px 0px 0px 1px inset;
 cursor: pointer;
 `),U("&:focus",`
 outline: none;
 `,[C("fill",[U("&::after",`
 position: absolute;
 top: 0;
 right: 0;
 bottom: 0;
 left: 0;
 background: inherit;
 filter: blur(2px);
 content: "";
 `)])])])])]),ki=Object.assign(Object.assign({},fe.props),{value:String,show:{type:Boolean,default:void 0},defaultShow:Boolean,defaultValue:String,modes:{type:Array,default:()=>["rgb","hex","hsl"]},placement:{type:String,default:"bottom-start"},to:Kt.propTo,showAlpha:{type:Boolean,default:!0},showPreview:Boolean,swatches:Array,disabled:{type:Boolean,default:void 0},actions:{type:Array,default:null},internalActions:Array,size:String,renderLabel:Function,onComplete:Function,onConfirm:Function,onClear:Function,"onUpdate:show":[Function,Array],onUpdateShow:[Function,Array],"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array]}),Ci=te({name:"ColorPicker",props:ki,slots:Object,setup(e,{slots:t}){const r=M(null);let n=null;const a=ir(e),{mergedSizeRef:i,mergedDisabledRef:o}=a,{localeRef:l}=jr("global"),{mergedClsPrefixRef:s,namespaceRef:c,inlineThemeDisabled:u}=Pe(e),f=fe("ColorPicker","-color-picker",Si,Nn,e,s);Ge(or,{themeRef:f,renderLabelRef:ie(e,"renderLabel"),colorPickerSlots:t});const x=M(e.defaultShow),S=Xe(ie(e,"show"),x);function v(w){const{onUpdateShow:q,"onUpdate:show":h}=e;q&&ue(q,w),h&&ue(h,w),x.value=w}const{defaultValue:m}=e,y=M(m===void 0?Ja(e.modes,e.showAlpha):m),b=Xe(ie(e,"value"),y),T=M([b.value]),R=M(0),P=I(()=>lt(b.value)),{modes:F}=e,k=M(lt(b.value)||F[0]||"rgb");function V(){const{modes:w}=e,{value:q}=k,h=w.findIndex(g=>g===q);~h?k.value=w[(h+1)%w.length]:k.value="rgb"}let _,O,N,H,j,G,B,L;const oe=I(()=>{const{value:w}=b;if(!w)return null;switch(P.value){case"hsv":return De(w);case"hsl":return[_,O,N,L]=Ke(w),[...Ur(_,O,N),L];case"rgb":case"hex":return[j,G,B,L]=$e(w),[...Dt(j,G,B),L]}}),J=I(()=>{const{value:w}=b;if(!w)return null;switch(P.value){case"rgb":case"hex":return $e(w);case"hsv":return[_,O,H,L]=De(w),[...Oe(_,O,H),L];case"hsl":return[_,O,N,L]=Ke(w),[...jt(_,O,N),L]}}),re=I(()=>{const{value:w}=b;if(!w)return null;switch(P.value){case"hsl":return Ke(w);case"hsv":return[_,O,H,L]=De(w),[...yt(_,O,H),L];case"rgb":case"hex":return[j,G,B,L]=$e(w),[...qt(j,G,B),L]}}),me=I(()=>{switch(k.value){case"rgb":case"hex":return J.value;case"hsv":return oe.value;case"hsl":return re.value}}),he=M(0),ne=M(1),ce=M([0,0]);function ye(w,q){const{value:h}=oe,g=he.value,z=h?h[3]:1;ce.value=[w,q];const{showAlpha:E}=e;switch(k.value){case"hsv":D((E?qe:Ht)([g,w,q,z]),"cursor");break;case"hsl":D((E?_e:Nt)([...yt(g,w,q),z]),"cursor");break;case"rgb":D((E?Ae:Wt)([...Oe(g,w,q),z]),"cursor");break;case"hex":D((E?Ie:it)([...Oe(g,w,q),z]),"cursor");break}}function be(w){he.value=w;const{value:q}=oe;if(!q)return;const[,h,g,z]=q,{showAlpha:E}=e;switch(k.value){case"hsv":D((E?qe:Ht)([w,h,g,z]),"cursor");break;case"rgb":D((E?Ae:Wt)([...Oe(w,h,g),z]),"cursor");break;case"hex":D((E?Ie:it)([...Oe(w,h,g),z]),"cursor");break;case"hsl":D((E?_e:Nt)([...yt(w,h,g),z]),"cursor");break}}function ge(w){switch(k.value){case"hsv":[_,O,H]=oe.value,D(qe([_,O,H,w]),"cursor");break;case"rgb":[j,G,B]=J.value,D(Ae([j,G,B,w]),"cursor");break;case"hex":[j,G,B]=J.value,D(Ie([j,G,B,w]),"cursor");break;case"hsl":[_,O,N]=re.value,D(_e([_,O,N,w]),"cursor");break}ne.value=w}function D(w,q){q==="cursor"?n=w:n=null;const{nTriggerFormChange:h,nTriggerFormInput:g}=a,{onUpdateValue:z,"onUpdate:value":E}=e;z&&ue(z,w),E&&ue(E,w),h(),g(),y.value=w}function ve(w){D(w,"input"),at(pe)}function pe(w=!0){const{value:q}=b;if(q){const{nTriggerFormChange:h,nTriggerFormInput:g}=a,{onComplete:z}=e;z&&z(q);const{value:E}=T,{value:K}=R;w&&(E.splice(K+1,E.length,q),R.value=K+1),h(),g()}}function Te(){const{value:w}=R;w-1<0||(D(T.value[w-1],"input"),pe(!1),R.value=w-1)}function xe(){const{value:w}=R;w<0||w+1>=T.value.length||(D(T.value[w+1],"input"),pe(!1),R.value=w+1)}function Fe(){D(null,"input");const{onClear:w}=e;w&&w(),v(!1)}function X(){const{value:w}=b,{onConfirm:q}=e;q&&q(w),v(!1)}const le=I(()=>R.value>=1),Y=I(()=>{const{value:w}=T;return w.length>1&&R.value<w.length-1});He(S,w=>{w||(T.value=[b.value],R.value=0)}),tr(()=>{if(!(n&&n===b.value)){const{value:w}=oe;w&&(he.value=w[0],ne.value=w[3],ce.value=[w[1],w[2]])}n=null});const Ce=I(()=>{const{value:w}=i,{common:{cubicBezierEaseInOut:q},self:{textColor:h,color:g,panelFontSize:z,boxShadow:E,border:K,borderRadius:ee,dividerColor:se,[Q("height",w)]:Ee,[Q("fontSize",w)]:Ve}}=f.value;return{"--n-bezier":q,"--n-text-color":h,"--n-color":g,"--n-panel-font-size":z,"--n-font-size":Ve,"--n-box-shadow":E,"--n-border":K,"--n-border-radius":ee,"--n-height":Ee,"--n-divider-color":se}}),ke=u?Le("color-picker",I(()=>i.value[0]),Ce,e):void 0;function $t(){var w;const{value:q}=J,{value:h}=he,{internalActions:g,modes:z,actions:E}=e,{value:K}=f,{value:ee}=s;return d("div",{class:[`${ee}-color-picker-panel`,ke?.themeClass.value],onDragstart:se=>{se.preventDefault()},style:u?void 0:Ce.value},d("div",{class:`${ee}-color-picker-control`},d(wi,{clsPrefix:ee,rgba:q,displayedHue:h,displayedSv:ce.value,onUpdateSV:ye,onComplete:pe}),d("div",{class:`${ee}-color-picker-preview`},d("div",{class:`${ee}-color-picker-preview__sliders`},d(xi,{clsPrefix:ee,hue:h,onUpdateHue:be,onComplete:pe}),e.showAlpha?d(ai,{clsPrefix:ee,rgba:q,alpha:ne.value,onUpdateAlpha:ge,onComplete:pe}):null),e.showPreview?d(gi,{clsPrefix:ee,mode:k.value,color:J.value&&it(J.value),onUpdateColor:se=>{D(se,"input")}}):null),d(ui,{clsPrefix:ee,showAlpha:e.showAlpha,mode:k.value,modes:z,onUpdateMode:V,value:b.value,valueArr:me.value,onUpdateValue:ve}),((w=e.swatches)===null||w===void 0?void 0:w.length)&&d(hi,{clsPrefix:ee,mode:k.value,swatches:e.swatches,onUpdateColor:se=>{D(se,"input")}})),E?.length?d("div",{class:`${ee}-color-picker-action`},E.includes("confirm")&&d(rt,{size:"small",onClick:X,theme:K.peers.Button,themeOverrides:K.peerOverrides.Button},{default:()=>l.value.confirm}),E.includes("clear")&&d(rt,{size:"small",onClick:Fe,disabled:!b.value,theme:K.peers.Button,themeOverrides:K.peerOverrides.Button},{default:()=>l.value.clear})):null,t.action?d("div",{class:`${ee}-color-picker-action`},{default:t.action}):g?d("div",{class:`${ee}-color-picker-action`},g.includes("undo")&&d(rt,{size:"small",onClick:Te,disabled:!le.value,theme:K.peers.Button,themeOverrides:K.peerOverrides.Button},{default:()=>l.value.undo}),g.includes("redo")&&d(rt,{size:"small",onClick:xe,disabled:!Y.value,theme:K.peers.Button,themeOverrides:K.peerOverrides.Button},{default:()=>l.value.redo})):null)}return{mergedClsPrefix:s,namespace:c,selfRef:r,hsla:re,rgba:J,mergedShow:S,mergedDisabled:o,isMounted:Wn(),adjustedTo:Kt(e),mergedValue:b,handleTriggerClick(){v(!0)},handleClickOutside(w){var q;!((q=r.value)===null||q===void 0)&&q.contains(Hn(w))||v(!1)},renderPanel:$t,cssVars:u?void 0:Ce,themeClass:ke?.themeClass,onRender:ke?.onRender}},render(){const{mergedClsPrefix:e,onRender:t}=this;return t?.(),d("div",{class:[this.themeClass,`${e}-color-picker`],ref:"selfRef",style:this.cssVars},d(ga,null,{default:()=>[d(va,null,{default:()=>d(bi,{clsPrefix:e,value:this.mergedValue,hsla:this.hsla,disabled:this.mergedDisabled,onClick:this.handleTriggerClick})}),d(ma,{placement:this.placement,show:this.mergedShow,containerClass:this.namespace,teleportDisabled:this.adjustedTo===Kt.tdkey,to:this.adjustedTo},{default:()=>d(Vr,{name:"fade-in-scale-up-transition",appear:this.isMounted},{default:()=>this.mergedShow?er(this.renderPanel(),[[ya,this.handleClickOutside,void 0,{capture:!0}]]):null})})]}))}}),Ri=p("divider",`
 position: relative;
 display: flex;
 width: 100%;
 box-sizing: border-box;
 font-size: 16px;
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
`,[je("vertical",`
 margin-top: 24px;
 margin-bottom: 24px;
 `,[je("no-title",`
 display: flex;
 align-items: center;
 `)]),C("title",`
 display: flex;
 align-items: center;
 margin-left: 12px;
 margin-right: 12px;
 white-space: nowrap;
 font-weight: var(--n-font-weight);
 `),$("title-position-left",[C("line",[$("left",{width:"28px"})])]),$("title-position-right",[C("line",[$("right",{width:"28px"})])]),$("dashed",[C("line",`
 background-color: #0000;
 height: 0px;
 width: 100%;
 border-style: dashed;
 border-width: 1px 0 0;
 `)]),$("vertical",`
 display: inline-block;
 height: 1em;
 margin: 0 8px;
 vertical-align: middle;
 width: 1px;
 `),C("line",`
 border: none;
 transition: background-color .3s var(--n-bezier), border-color .3s var(--n-bezier);
 height: 1px;
 width: 100%;
 margin: 0;
 `),je("dashed",[C("line",{backgroundColor:"var(--n-color)"})]),$("dashed",[C("line",{borderColor:"var(--n-color)"})]),$("vertical",{backgroundColor:"var(--n-color)"})]),$i=Object.assign(Object.assign({},fe.props),{titlePlacement:{type:String,default:"center"},dashed:Boolean,vertical:Boolean}),zi=te({name:"Divider",props:$i,setup(e){const{mergedClsPrefixRef:t,inlineThemeDisabled:r}=Pe(e),n=fe("Divider","-divider",Ri,Kn,e,t),a=I(()=>{const{common:{cubicBezierEaseInOut:o},self:{color:l,textColor:s,fontWeight:c}}=n.value;return{"--n-bezier":o,"--n-color":l,"--n-text-color":s,"--n-font-weight":c}}),i=r?Le("divider",void 0,a,e):void 0;return{mergedClsPrefix:t,cssVars:r?void 0:a,themeClass:i?.themeClass,onRender:i?.onRender}},render(){var e;const{$slots:t,titlePlacement:r,vertical:n,dashed:a,cssVars:i,mergedClsPrefix:o}=this;return(e=this.onRender)===null||e===void 0||e.call(this),d("div",{role:"separator",class:[`${o}-divider`,this.themeClass,{[`${o}-divider--vertical`]:n,[`${o}-divider--no-title`]:!t.default,[`${o}-divider--dashed`]:a,[`${o}-divider--title-position-${r}`]:t.default&&r}],style:i},n?null:d("div",{class:`${o}-divider__line ${o}-divider__line--left`}),!n&&t.default?d(Ct,null,d("div",{class:`${o}-divider__title`},this.$slots),d("div",{class:`${o}-divider__line ${o}-divider__line--right`})):null)}});let Et;function Pi(){if(!Gn)return!0;if(Et===void 0){const e=document.createElement("div");e.style.display="flex",e.style.flexDirection="column",e.style.rowGap="1px",e.appendChild(document.createElement("div")),e.appendChild(document.createElement("div")),document.body.appendChild(e);const t=e.scrollHeight===1;return document.body.removeChild(e),Et=t}return Et}const _i=Object.assign(Object.assign({},fe.props),{align:String,justify:{type:String,default:"start"},inline:Boolean,vertical:Boolean,reverse:Boolean,size:{type:[String,Number,Array],default:"medium"},wrapItem:{type:Boolean,default:!0},itemClass:String,itemStyle:[String,Object],wrap:{type:Boolean,default:!0},internalUseGap:{type:Boolean,default:void 0}}),Ai=te({name:"Space",props:_i,setup(e){const{mergedClsPrefixRef:t,mergedRtlRef:r}=Pe(e),n=fe("Space","-space",void 0,Xn,e,t),a=nr("Space",r,t);return{useGap:Pi(),rtlEnabled:a,mergedClsPrefix:t,margin:I(()=>{const{size:i}=e;if(Array.isArray(i))return{horizontal:i[0],vertical:i[1]};if(typeof i=="number")return{horizontal:i,vertical:i};const{self:{[Q("gap",i)]:o}}=n.value,{row:l,col:s}=Yn(o);return{horizontal:Se(s),vertical:Se(l)}})}},render(){const{vertical:e,reverse:t,align:r,inline:n,justify:a,itemClass:i,itemStyle:o,margin:l,wrap:s,mergedClsPrefix:c,rtlEnabled:u,useGap:f,wrapItem:x,internalUseGap:S}=this,v=xt(_a(this),!1);if(!v.length)return null;const m=`${l.horizontal}px`,y=`${l.horizontal/2}px`,b=`${l.vertical}px`,T=`${l.vertical/2}px`,R=v.length-1,P=a.startsWith("space-");return d("div",{role:"none",class:[`${c}-space`,u&&`${c}-space--rtl`],style:{display:n?"inline-flex":"flex",flexDirection:e&&!t?"column":e&&t?"column-reverse":!e&&t?"row-reverse":"row",justifyContent:["start","end"].includes(a)?`flex-${a}`:a,flexWrap:!s||e?"nowrap":"wrap",marginTop:f||e?"":`-${T}`,marginBottom:f||e?"":`-${T}`,alignItems:r,gap:f?`${l.vertical}px ${l.horizontal}px`:""}},!x&&(f||S)?v:v.map((F,k)=>F.type===Rn?F:d("div",{role:"none",class:i,style:[o,{maxWidth:"100%"},f?"":e?{marginBottom:k!==R?b:""}:u?{marginLeft:P?a==="space-between"&&k===R?"":y:k!==R?m:"",marginRight:P?a==="space-between"&&k===0?"":y:"",paddingTop:T,paddingBottom:T}:{marginRight:P?a==="space-between"&&k===R?"":y:k!==R?m:"",marginLeft:P?a==="space-between"&&k===0?"":y:"",paddingTop:T,paddingBottom:T}]},F)))}}),Ti=p("dynamic-tags",[p("input",{minWidth:"var(--n-input-width)"})]),Fi=Object.assign(Object.assign(Object.assign({},fe.props),wa),{size:{type:String,default:"medium"},closable:{type:Boolean,default:!0},defaultValue:{type:Array,default:()=>[]},value:Array,inputClass:String,inputStyle:[String,Object],inputProps:Object,max:Number,tagClass:String,tagStyle:[String,Object],renderTag:Function,onCreate:{type:Function,default:e=>e},"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],onChange:[Function,Array]}),Ei=te({name:"DynamicTags",props:Fi,slots:Object,setup(e){const{mergedClsPrefixRef:t,inlineThemeDisabled:r}=Pe(e),{localeRef:n}=jr("DynamicTags"),a=ir(e),{mergedDisabledRef:i}=a,o=M(""),l=M(!1),s=M(!0),c=M(null),u=fe("DynamicTags","-dynamic-tags",Ti,Zn,e,t),f=M(e.defaultValue),x=ie(e,"value"),S=Xe(x,f),v=I(()=>n.value.add),m=I(()=>Pa(e.size)),y=I(()=>i.value||!!e.max&&S.value.length>=e.max);function b(O){const{onChange:N,"onUpdate:value":H,onUpdateValue:j}=e,{nTriggerFormInput:G,nTriggerFormChange:B}=a;N&&ue(N,O),j&&ue(j,O),H&&ue(H,O),f.value=O,G(),B()}function T(O){const N=S.value.slice(0);N.splice(O,1),b(N)}function R(O){switch(O.key){case"Enter":P()}}function P(O){const N=O??o.value;if(N){const H=S.value.slice(0);H.push(e.onCreate(N)),b(H)}l.value=!1,s.value=!0,o.value=""}function F(){P()}function k(){l.value=!0,at(()=>{var O;(O=c.value)===null||O===void 0||O.focus(),s.value=!1})}const V=I(()=>{const{self:{inputWidth:O}}=u.value;return{"--n-input-width":O}}),_=r?Le("dynamic-tags",void 0,V,e):void 0;return{mergedClsPrefix:t,inputInstRef:c,localizedAdd:v,inputSize:m,inputValue:o,showInput:l,inputForceFocused:s,mergedValue:S,mergedDisabled:i,triggerDisabled:y,handleInputKeyDown:R,handleAddClick:k,handleInputBlur:F,handleCloseClick:T,handleInputConfirm:P,mergedTheme:u,cssVars:r?void 0:V,themeClass:_?.themeClass,onRender:_?.onRender}},render(){const{mergedTheme:e,cssVars:t,mergedClsPrefix:r,onRender:n,renderTag:a}=this;return n?.(),d(Ai,{class:[`${r}-dynamic-tags`,this.themeClass],size:"small",style:t,theme:e.peers.Space,themeOverrides:e.peerOverrides.Space,itemStyle:"display: flex;"},{default:()=>{const{mergedTheme:i,tagClass:o,tagStyle:l,type:s,round:c,size:u,color:f,closable:x,mergedDisabled:S,showInput:v,inputValue:m,inputClass:y,inputStyle:b,inputSize:T,inputForceFocused:R,triggerDisabled:P,handleInputKeyDown:F,handleInputBlur:k,handleAddClick:V,handleCloseClick:_,handleInputConfirm:O,$slots:N}=this;return this.mergedValue.map((H,j)=>a?a(H,j):d(xa,{key:j,theme:i.peers.Tag,themeOverrides:i.peerOverrides.Tag,class:o,style:l,type:s,round:c,size:u,color:f,closable:x,disabled:S,onClose:()=>{_(j)}},{default:()=>typeof H=="string"?H:H.label})).concat(v?N.input?N.input({submit:O,deactivate:k}):d(Rt,Object.assign({placeholder:"",size:T,style:b,class:y,autosize:!0},this.inputProps,{ref:"inputInstRef",value:m,onUpdateValue:H=>{this.inputValue=H},theme:i.peers.Input,themeOverrides:i.peerOverrides.Input,onKeydown:F,onBlur:k,internalForceFocus:R})):N.trigger?N.trigger({activate:V,disabled:P}):d(rt,{dashed:!0,disabled:P,theme:i.peers.Button,themeOverrides:i.peerOverrides.Button,size:T,onClick:V},{icon:()=>d(ar,{clsPrefix:r},{default:()=>d(Nr,null)})}))}})}}),ct=dt("n-form"),Kr=dt("n-form-item-insts"),Oi=p("form",[$("inline",`
 width: 100%;
 display: inline-flex;
 align-items: flex-start;
 align-content: space-around;
 `,[p("form-item",{width:"auto",marginRight:"18px"},[U("&:last-child",{marginRight:0})])])]);var Ii=function(e,t,r,n){function a(i){return i instanceof r?i:new r(function(o){o(i)})}return new(r||(r=Promise))(function(i,o){function l(u){try{c(n.next(u))}catch(f){o(f)}}function s(u){try{c(n.throw(u))}catch(f){o(f)}}function c(u){u.done?i(u.value):a(u.value).then(l,s)}c((n=n.apply(e,t||[])).next())})};const Vi=Object.assign(Object.assign({},fe.props),{inline:Boolean,labelWidth:[Number,String],labelAlign:String,labelPlacement:{type:String,default:"top"},model:{type:Object,default:()=>{}},rules:Object,disabled:Boolean,size:String,showRequireMark:{type:Boolean,default:void 0},requireMarkPlacement:String,showFeedback:{type:Boolean,default:!0},onSubmit:{type:Function,default:e=>{e.preventDefault()}},showLabel:{type:Boolean,default:void 0},validateMessages:Object}),Bi=te({name:"Form",props:Vi,setup(e){const{mergedClsPrefixRef:t}=Pe(e);fe("Form","-form",Oi,Dr,e,t);const r={},n=M(void 0),a=s=>{const c=n.value;(c===void 0||s>=c)&&(n.value=s)};function i(s){return Ii(this,arguments,void 0,function*(c,u=()=>!0){return yield new Promise((f,x)=>{const S=[];for(const v of mr(r)){const m=r[v];for(const y of m)y.path&&S.push(y.internalValidate(null,u))}Promise.all(S).then(v=>{const m=v.some(T=>!T.valid),y=[],b=[];v.forEach(T=>{var R,P;!((R=T.errors)===null||R===void 0)&&R.length&&y.push(T.errors),!((P=T.warnings)===null||P===void 0)&&P.length&&b.push(T.warnings)}),c&&c(y.length?y:void 0,{warnings:b.length?b:void 0}),m?x(y.length?y:void 0):f({warnings:b.length?b:void 0})})})})}function o(){for(const s of mr(r)){const c=r[s];for(const u of c)u.restoreValidation()}}return Ge(ct,{props:e,maxChildLabelWidthRef:n,deriveMaxChildLabelWidth:a}),Ge(Kr,{formItems:r}),Object.assign({validate:i,restoreValidation:o},{mergedClsPrefix:t})},render(){const{mergedClsPrefix:e}=this;return d("form",{class:[`${e}-form`,this.inline&&`${e}-form--inline`],onSubmit:this.onSubmit},this.$slots)}});function Ue(){return Ue=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e},Ue.apply(this,arguments)}function Mi(e,t){e.prototype=Object.create(t.prototype),e.prototype.constructor=e,st(e,t)}function Gt(e){return Gt=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(r){return r.__proto__||Object.getPrototypeOf(r)},Gt(e)}function st(e,t){return st=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(n,a){return n.__proto__=a,n},st(e,t)}function Ui(){if(typeof Reflect>"u"||!Reflect.construct||Reflect.construct.sham)return!1;if(typeof Proxy=="function")return!0;try{return Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){})),!0}catch{return!1}}function St(e,t,r){return Ui()?St=Reflect.construct.bind():St=function(a,i,o){var l=[null];l.push.apply(l,i);var s=Function.bind.apply(a,l),c=new s;return o&&st(c,o.prototype),c},St.apply(null,arguments)}function ji(e){return Function.toString.call(e).indexOf("[native code]")!==-1}function Xt(e){var t=typeof Map=="function"?new Map:void 0;return Xt=function(n){if(n===null||!ji(n))return n;if(typeof n!="function")throw new TypeError("Super expression must either be null or a function");if(typeof t<"u"){if(t.has(n))return t.get(n);t.set(n,a)}function a(){return St(n,arguments,Gt(this).constructor)}return a.prototype=Object.create(n.prototype,{constructor:{value:a,enumerable:!1,writable:!0,configurable:!0}}),st(a,n)},Xt(e)}var Di=/%[sdj%]/g,qi=function(){};function Yt(e){if(!e||!e.length)return null;var t={};return e.forEach(function(r){var n=r.field;t[n]=t[n]||[],t[n].push(r)}),t}function we(e){for(var t=arguments.length,r=new Array(t>1?t-1:0),n=1;n<t;n++)r[n-1]=arguments[n];var a=0,i=r.length;if(typeof e=="function")return e.apply(null,r);if(typeof e=="string"){var o=e.replace(Di,function(l){if(l==="%%")return"%";if(a>=i)return l;switch(l){case"%s":return String(r[a++]);case"%d":return Number(r[a++]);case"%j":try{return JSON.stringify(r[a++])}catch{return"[Circular]"}break;default:return l}});return o}return e}function Li(e){return e==="string"||e==="url"||e==="hex"||e==="email"||e==="date"||e==="pattern"}function de(e,t){return!!(e==null||t==="array"&&Array.isArray(e)&&!e.length||Li(t)&&typeof e=="string"&&!e)}function Ni(e,t,r){var n=[],a=0,i=e.length;function o(l){n.push.apply(n,l||[]),a++,a===i&&r(n)}e.forEach(function(l){t(l,o)})}function Sr(e,t,r){var n=0,a=e.length;function i(o){if(o&&o.length){r(o);return}var l=n;n=n+1,l<a?t(e[l],i):r([])}i([])}function Wi(e){var t=[];return Object.keys(e).forEach(function(r){t.push.apply(t,e[r]||[])}),t}var kr=function(e){Mi(t,e);function t(r,n){var a;return a=e.call(this,"Async Validation Error")||this,a.errors=r,a.fields=n,a}return t}(Xt(Error));function Hi(e,t,r,n,a){if(t.first){var i=new Promise(function(x,S){var v=function(b){return n(b),b.length?S(new kr(b,Yt(b))):x(a)},m=Wi(e);Sr(m,r,v)});return i.catch(function(x){return x}),i}var o=t.firstFields===!0?Object.keys(e):t.firstFields||[],l=Object.keys(e),s=l.length,c=0,u=[],f=new Promise(function(x,S){var v=function(y){if(u.push.apply(u,y),c++,c===s)return n(u),u.length?S(new kr(u,Yt(u))):x(a)};l.length||(n(u),x(a)),l.forEach(function(m){var y=e[m];o.indexOf(m)!==-1?Sr(y,r,v):Ni(y,r,v)})});return f.catch(function(x){return x}),f}function Ki(e){return!!(e&&e.message!==void 0)}function Gi(e,t){for(var r=e,n=0;n<t.length;n++){if(r==null)return r;r=r[t[n]]}return r}function Cr(e,t){return function(r){var n;return e.fullFields?n=Gi(t,e.fullFields):n=t[r.field||e.fullField],Ki(r)?(r.field=r.field||e.fullField,r.fieldValue=n,r):{message:typeof r=="function"?r():r,fieldValue:n,field:r.field||e.fullField}}}function Rr(e,t){if(t){for(var r in t)if(t.hasOwnProperty(r)){var n=t[r];typeof n=="object"&&typeof e[r]=="object"?e[r]=Ue({},e[r],n):e[r]=n}}return e}var Gr=function(t,r,n,a,i,o){t.required&&(!n.hasOwnProperty(t.field)||de(r,o||t.type))&&a.push(we(i.messages.required,t.fullField))},Xi=function(t,r,n,a,i){(/^\s+$/.test(r)||r==="")&&a.push(we(i.messages.whitespace,t.fullField))},gt,Yi=function(){if(gt)return gt;var e="[a-fA-F\\d:]",t=function(P){return P&&P.includeBoundaries?"(?:(?<=\\s|^)(?="+e+")|(?<="+e+")(?=\\s|$))":""},r="(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)(?:\\.(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)){3}",n="[a-fA-F\\d]{1,4}",a=(`
(?:
(?:`+n+":){7}(?:"+n+`|:)|                                    // 1:2:3:4:5:6:7::  1:2:3:4:5:6:7:8
(?:`+n+":){6}(?:"+r+"|:"+n+`|:)|                             // 1:2:3:4:5:6::    1:2:3:4:5:6::8   1:2:3:4:5:6::8  1:2:3:4:5:6::1.2.3.4
(?:`+n+":){5}(?::"+r+"|(?::"+n+`){1,2}|:)|                   // 1:2:3:4:5::      1:2:3:4:5::7:8   1:2:3:4:5::8    1:2:3:4:5::7:1.2.3.4
(?:`+n+":){4}(?:(?::"+n+"){0,1}:"+r+"|(?::"+n+`){1,3}|:)| // 1:2:3:4::        1:2:3:4::6:7:8   1:2:3:4::8      1:2:3:4::6:7:1.2.3.4
(?:`+n+":){3}(?:(?::"+n+"){0,2}:"+r+"|(?::"+n+`){1,4}|:)| // 1:2:3::          1:2:3::5:6:7:8   1:2:3::8        1:2:3::5:6:7:1.2.3.4
(?:`+n+":){2}(?:(?::"+n+"){0,3}:"+r+"|(?::"+n+`){1,5}|:)| // 1:2::            1:2::4:5:6:7:8   1:2::8          1:2::4:5:6:7:1.2.3.4
(?:`+n+":){1}(?:(?::"+n+"){0,4}:"+r+"|(?::"+n+`){1,6}|:)| // 1::              1::3:4:5:6:7:8   1::8            1::3:4:5:6:7:1.2.3.4
(?::(?:(?::`+n+"){0,5}:"+r+"|(?::"+n+`){1,7}|:))             // ::2:3:4:5:6:7:8  ::2:3:4:5:6:7:8  ::8             ::1.2.3.4
)(?:%[0-9a-zA-Z]{1,})?                                             // %eth0            %1
`).replace(/\s*\/\/.*$/gm,"").replace(/\n/g,"").trim(),i=new RegExp("(?:^"+r+"$)|(?:^"+a+"$)"),o=new RegExp("^"+r+"$"),l=new RegExp("^"+a+"$"),s=function(P){return P&&P.exact?i:new RegExp("(?:"+t(P)+r+t(P)+")|(?:"+t(P)+a+t(P)+")","g")};s.v4=function(R){return R&&R.exact?o:new RegExp(""+t(R)+r+t(R),"g")},s.v6=function(R){return R&&R.exact?l:new RegExp(""+t(R)+a+t(R),"g")};var c="(?:(?:[a-z]+:)?//)",u="(?:\\S+(?::\\S*)?@)?",f=s.v4().source,x=s.v6().source,S="(?:(?:[a-z\\u00a1-\\uffff0-9][-_]*)*[a-z\\u00a1-\\uffff0-9]+)",v="(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*",m="(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))",y="(?::\\d{2,5})?",b='(?:[/?#][^\\s"]*)?',T="(?:"+c+"|www\\.)"+u+"(?:localhost|"+f+"|"+x+"|"+S+v+m+")"+y+b;return gt=new RegExp("(?:^"+T+"$)","i"),gt},$r={email:/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+\.)+[a-zA-Z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]{2,}))$/,hex:/^#?([a-f0-9]{6}|[a-f0-9]{3})$/i},nt={integer:function(t){return nt.number(t)&&parseInt(t,10)===t},float:function(t){return nt.number(t)&&!nt.integer(t)},array:function(t){return Array.isArray(t)},regexp:function(t){if(t instanceof RegExp)return!0;try{return!!new RegExp(t)}catch{return!1}},date:function(t){return typeof t.getTime=="function"&&typeof t.getMonth=="function"&&typeof t.getYear=="function"&&!isNaN(t.getTime())},number:function(t){return isNaN(t)?!1:typeof t=="number"},object:function(t){return typeof t=="object"&&!nt.array(t)},method:function(t){return typeof t=="function"},email:function(t){return typeof t=="string"&&t.length<=320&&!!t.match($r.email)},url:function(t){return typeof t=="string"&&t.length<=2048&&!!t.match(Yi())},hex:function(t){return typeof t=="string"&&!!t.match($r.hex)}},Zi=function(t,r,n,a,i){if(t.required&&r===void 0){Gr(t,r,n,a,i);return}var o=["integer","float","array","regexp","object","method","email","number","date","url","hex"],l=t.type;o.indexOf(l)>-1?nt[l](r)||a.push(we(i.messages.types[l],t.fullField,t.type)):l&&typeof r!==t.type&&a.push(we(i.messages.types[l],t.fullField,t.type))},Ji=function(t,r,n,a,i){var o=typeof t.len=="number",l=typeof t.min=="number",s=typeof t.max=="number",c=/[\uD800-\uDBFF][\uDC00-\uDFFF]/g,u=r,f=null,x=typeof r=="number",S=typeof r=="string",v=Array.isArray(r);if(x?f="number":S?f="string":v&&(f="array"),!f)return!1;v&&(u=r.length),S&&(u=r.replace(c,"_").length),o?u!==t.len&&a.push(we(i.messages[f].len,t.fullField,t.len)):l&&!s&&u<t.min?a.push(we(i.messages[f].min,t.fullField,t.min)):s&&!l&&u>t.max?a.push(we(i.messages[f].max,t.fullField,t.max)):l&&s&&(u<t.min||u>t.max)&&a.push(we(i.messages[f].range,t.fullField,t.min,t.max))},We="enum",Qi=function(t,r,n,a,i){t[We]=Array.isArray(t[We])?t[We]:[],t[We].indexOf(r)===-1&&a.push(we(i.messages[We],t.fullField,t[We].join(", ")))},eo=function(t,r,n,a,i){if(t.pattern){if(t.pattern instanceof RegExp)t.pattern.lastIndex=0,t.pattern.test(r)||a.push(we(i.messages.pattern.mismatch,t.fullField,r,t.pattern));else if(typeof t.pattern=="string"){var o=new RegExp(t.pattern);o.test(r)||a.push(we(i.messages.pattern.mismatch,t.fullField,r,t.pattern))}}},W={required:Gr,whitespace:Xi,type:Zi,range:Ji,enum:Qi,pattern:eo},to=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(de(r,"string")&&!t.required)return n();W.required(t,r,a,o,i,"string"),de(r,"string")||(W.type(t,r,a,o,i),W.range(t,r,a,o,i),W.pattern(t,r,a,o,i),t.whitespace===!0&&W.whitespace(t,r,a,o,i))}n(o)},ro=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(de(r)&&!t.required)return n();W.required(t,r,a,o,i),r!==void 0&&W.type(t,r,a,o,i)}n(o)},no=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(r===""&&(r=void 0),de(r)&&!t.required)return n();W.required(t,r,a,o,i),r!==void 0&&(W.type(t,r,a,o,i),W.range(t,r,a,o,i))}n(o)},ao=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(de(r)&&!t.required)return n();W.required(t,r,a,o,i),r!==void 0&&W.type(t,r,a,o,i)}n(o)},io=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(de(r)&&!t.required)return n();W.required(t,r,a,o,i),de(r)||W.type(t,r,a,o,i)}n(o)},oo=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(de(r)&&!t.required)return n();W.required(t,r,a,o,i),r!==void 0&&(W.type(t,r,a,o,i),W.range(t,r,a,o,i))}n(o)},lo=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(de(r)&&!t.required)return n();W.required(t,r,a,o,i),r!==void 0&&(W.type(t,r,a,o,i),W.range(t,r,a,o,i))}n(o)},so=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(r==null&&!t.required)return n();W.required(t,r,a,o,i,"array"),r!=null&&(W.type(t,r,a,o,i),W.range(t,r,a,o,i))}n(o)},co=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(de(r)&&!t.required)return n();W.required(t,r,a,o,i),r!==void 0&&W.type(t,r,a,o,i)}n(o)},uo="enum",fo=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(de(r)&&!t.required)return n();W.required(t,r,a,o,i),r!==void 0&&W[uo](t,r,a,o,i)}n(o)},po=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(de(r,"string")&&!t.required)return n();W.required(t,r,a,o,i),de(r,"string")||W.pattern(t,r,a,o,i)}n(o)},ho=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(de(r,"date")&&!t.required)return n();if(W.required(t,r,a,o,i),!de(r,"date")){var s;r instanceof Date?s=r:s=new Date(r),W.type(t,s,a,o,i),s&&W.range(t,s.getTime(),a,o,i)}}n(o)},bo=function(t,r,n,a,i){var o=[],l=Array.isArray(r)?"array":typeof r;W.required(t,r,a,o,i,l),n(o)},Ot=function(t,r,n,a,i){var o=t.type,l=[],s=t.required||!t.required&&a.hasOwnProperty(t.field);if(s){if(de(r,o)&&!t.required)return n();W.required(t,r,a,l,i,o),de(r,o)||W.type(t,r,a,l,i)}n(l)},go=function(t,r,n,a,i){var o=[],l=t.required||!t.required&&a.hasOwnProperty(t.field);if(l){if(de(r)&&!t.required)return n();W.required(t,r,a,o,i)}n(o)},ot={string:to,method:ro,number:no,boolean:ao,regexp:io,integer:oo,float:lo,array:so,object:co,enum:fo,pattern:po,date:ho,url:Ot,hex:Ot,email:Ot,required:bo,any:go};function Zt(){return{default:"Validation error on field %s",required:"%s is required",enum:"%s must be one of %s",whitespace:"%s cannot be empty",date:{format:"%s date %s is invalid for format %s",parse:"%s date could not be parsed, %s is invalid ",invalid:"%s date %s is invalid"},types:{string:"%s is not a %s",method:"%s is not a %s (function)",array:"%s is not an %s",object:"%s is not an %s",number:"%s is not a %s",date:"%s is not a %s",boolean:"%s is not a %s",integer:"%s is not an %s",float:"%s is not a %s",regexp:"%s is not a valid %s",email:"%s is not a valid %s",url:"%s is not a valid %s",hex:"%s is not a valid %s"},string:{len:"%s must be exactly %s characters",min:"%s must be at least %s characters",max:"%s cannot be longer than %s characters",range:"%s must be between %s and %s characters"},number:{len:"%s must equal %s",min:"%s cannot be less than %s",max:"%s cannot be greater than %s",range:"%s must be between %s and %s"},array:{len:"%s must be exactly %s in length",min:"%s cannot be less than %s in length",max:"%s cannot be greater than %s in length",range:"%s must be between %s and %s in length"},pattern:{mismatch:"%s value %s does not match pattern %s"},clone:function(){var t=JSON.parse(JSON.stringify(this));return t.clone=this.clone,t}}}var Jt=Zt(),Je=function(){function e(r){this.rules=null,this._messages=Jt,this.define(r)}var t=e.prototype;return t.define=function(n){var a=this;if(!n)throw new Error("Cannot configure a schema with no rules");if(typeof n!="object"||Array.isArray(n))throw new Error("Rules must be an object");this.rules={},Object.keys(n).forEach(function(i){var o=n[i];a.rules[i]=Array.isArray(o)?o:[o]})},t.messages=function(n){return n&&(this._messages=Rr(Zt(),n)),this._messages},t.validate=function(n,a,i){var o=this;a===void 0&&(a={}),i===void 0&&(i=function(){});var l=n,s=a,c=i;if(typeof s=="function"&&(c=s,s={}),!this.rules||Object.keys(this.rules).length===0)return c&&c(null,l),Promise.resolve(l);function u(m){var y=[],b={};function T(P){if(Array.isArray(P)){var F;y=(F=y).concat.apply(F,P)}else y.push(P)}for(var R=0;R<m.length;R++)T(m[R]);y.length?(b=Yt(y),c(y,b)):c(null,l)}if(s.messages){var f=this.messages();f===Jt&&(f=Zt()),Rr(f,s.messages),s.messages=f}else s.messages=this.messages();var x={},S=s.keys||Object.keys(this.rules);S.forEach(function(m){var y=o.rules[m],b=l[m];y.forEach(function(T){var R=T;typeof R.transform=="function"&&(l===n&&(l=Ue({},l)),b=l[m]=R.transform(b)),typeof R=="function"?R={validator:R}:R=Ue({},R),R.validator=o.getValidationMethod(R),R.validator&&(R.field=m,R.fullField=R.fullField||m,R.type=o.getType(R),x[m]=x[m]||[],x[m].push({rule:R,value:b,source:l,field:m}))})});var v={};return Hi(x,s,function(m,y){var b=m.rule,T=(b.type==="object"||b.type==="array")&&(typeof b.fields=="object"||typeof b.defaultField=="object");T=T&&(b.required||!b.required&&m.value),b.field=m.field;function R(k,V){return Ue({},V,{fullField:b.fullField+"."+k,fullFields:b.fullFields?[].concat(b.fullFields,[k]):[k]})}function P(k){k===void 0&&(k=[]);var V=Array.isArray(k)?k:[k];!s.suppressWarning&&V.length&&e.warning("async-validator:",V),V.length&&b.message!==void 0&&(V=[].concat(b.message));var _=V.map(Cr(b,l));if(s.first&&_.length)return v[b.field]=1,y(_);if(!T)y(_);else{if(b.required&&!m.value)return b.message!==void 0?_=[].concat(b.message).map(Cr(b,l)):s.error&&(_=[s.error(b,we(s.messages.required,b.field))]),y(_);var O={};b.defaultField&&Object.keys(m.value).map(function(j){O[j]=b.defaultField}),O=Ue({},O,m.rule.fields);var N={};Object.keys(O).forEach(function(j){var G=O[j],B=Array.isArray(G)?G:[G];N[j]=B.map(R.bind(null,j))});var H=new e(N);H.messages(s.messages),m.rule.options&&(m.rule.options.messages=s.messages,m.rule.options.error=s.error),H.validate(m.value,m.rule.options||s,function(j){var G=[];_&&_.length&&G.push.apply(G,_),j&&j.length&&G.push.apply(G,j),y(G.length?G:null)})}}var F;if(b.asyncValidator)F=b.asyncValidator(b,m.value,P,m.source,s);else if(b.validator){try{F=b.validator(b,m.value,P,m.source,s)}catch(k){console.error?.(k),s.suppressValidatorError||setTimeout(function(){throw k},0),P(k.message)}F===!0?P():F===!1?P(typeof b.message=="function"?b.message(b.fullField||b.field):b.message||(b.fullField||b.field)+" fails"):F instanceof Array?P(F):F instanceof Error&&P(F.message)}F&&F.then&&F.then(function(){return P()},function(k){return P(k)})},function(m){u(m)},l)},t.getType=function(n){if(n.type===void 0&&n.pattern instanceof RegExp&&(n.type="pattern"),typeof n.validator!="function"&&n.type&&!ot.hasOwnProperty(n.type))throw new Error(we("Unknown rule type %s",n.type));return n.type||"string"},t.getValidationMethod=function(n){if(typeof n.validator=="function")return n.validator;var a=Object.keys(n),i=a.indexOf("message");return i!==-1&&a.splice(i,1),a.length===1&&a[0]==="required"?ot.required:ot[this.getType(n)]||void 0},e}();Je.register=function(t,r){if(typeof r!="function")throw new Error("Cannot register a validator by type, validator is not a function");ot[t]=r};Je.warning=qi;Je.messages=Jt;Je.validators=ot;const{cubicBezierEaseInOut:zr}=Jn;function vo({name:e="fade-down",fromOffset:t="-4px",enterDuration:r=".3s",leaveDuration:n=".3s",enterCubicBezier:a=zr,leaveCubicBezier:i=zr}={}){return[U(`&.${e}-transition-enter-from, &.${e}-transition-leave-to`,{opacity:0,transform:`translateY(${t})`}),U(`&.${e}-transition-enter-to, &.${e}-transition-leave-from`,{opacity:1,transform:"translateY(0)"}),U(`&.${e}-transition-leave-active`,{transition:`opacity ${n} ${i}, transform ${n} ${i}`}),U(`&.${e}-transition-enter-active`,{transition:`opacity ${r} ${a}, transform ${r} ${a}`})]}const mo=p("form-item",`
 display: grid;
 line-height: var(--n-line-height);
`,[p("form-item-label",`
 grid-area: label;
 align-items: center;
 line-height: 1.25;
 text-align: var(--n-label-text-align);
 font-size: var(--n-label-font-size);
 min-height: var(--n-label-height);
 padding: var(--n-label-padding);
 color: var(--n-label-text-color);
 transition: color .3s var(--n-bezier);
 box-sizing: border-box;
 font-weight: var(--n-label-font-weight);
 `,[C("asterisk",`
 white-space: nowrap;
 user-select: none;
 -webkit-user-select: none;
 color: var(--n-asterisk-color);
 transition: color .3s var(--n-bezier);
 `),C("asterisk-placeholder",`
 grid-area: mark;
 user-select: none;
 -webkit-user-select: none;
 visibility: hidden; 
 `)]),p("form-item-blank",`
 grid-area: blank;
 min-height: var(--n-blank-height);
 `),$("auto-label-width",[p("form-item-label","white-space: nowrap;")]),$("left-labelled",`
 grid-template-areas:
 "label blank"
 "label feedback";
 grid-template-columns: auto minmax(0, 1fr);
 grid-template-rows: auto 1fr;
 align-items: flex-start;
 `,[p("form-item-label",`
 display: grid;
 grid-template-columns: 1fr auto;
 min-height: var(--n-blank-height);
 height: auto;
 box-sizing: border-box;
 flex-shrink: 0;
 flex-grow: 0;
 `,[$("reverse-columns-space",`
 grid-template-columns: auto 1fr;
 `),$("left-mark",`
 grid-template-areas:
 "mark text"
 ". text";
 `),$("right-mark",`
 grid-template-areas: 
 "text mark"
 "text .";
 `),$("right-hanging-mark",`
 grid-template-areas: 
 "text mark"
 "text .";
 `),C("text",`
 grid-area: text; 
 `),C("asterisk",`
 grid-area: mark; 
 align-self: end;
 `)])]),$("top-labelled",`
 grid-template-areas:
 "label"
 "blank"
 "feedback";
 grid-template-rows: minmax(var(--n-label-height), auto) 1fr;
 grid-template-columns: minmax(0, 100%);
 `,[$("no-label",`
 grid-template-areas:
 "blank"
 "feedback";
 grid-template-rows: 1fr;
 `),p("form-item-label",`
 display: flex;
 align-items: flex-start;
 justify-content: var(--n-label-text-align);
 `)]),p("form-item-blank",`
 box-sizing: border-box;
 display: flex;
 align-items: center;
 position: relative;
 `),p("form-item-feedback-wrapper",`
 grid-area: feedback;
 box-sizing: border-box;
 min-height: var(--n-feedback-height);
 font-size: var(--n-feedback-font-size);
 line-height: 1.25;
 transform-origin: top left;
 `,[U("&:not(:empty)",`
 padding: var(--n-feedback-padding);
 `),p("form-item-feedback",{transition:"color .3s var(--n-bezier)",color:"var(--n-feedback-text-color)"},[$("warning",{color:"var(--n-feedback-text-color-warning)"}),$("error",{color:"var(--n-feedback-text-color-error)"}),vo({fromOffset:"-3px",enterDuration:".3s",leaveDuration:".2s"})])])]);function yo(e){const t=ze(ct,null);return{mergedSize:I(()=>e.size!==void 0?e.size:t?.props.size!==void 0?t.props.size:"medium")}}function xo(e){const t=ze(ct,null),r=I(()=>{const{labelPlacement:v}=e;return v!==void 0?v:t?.props.labelPlacement?t.props.labelPlacement:"top"}),n=I(()=>r.value==="left"&&(e.labelWidth==="auto"||t?.props.labelWidth==="auto")),a=I(()=>{if(r.value==="top")return;const{labelWidth:v}=e;if(v!==void 0&&v!=="auto")return zt(v);if(n.value){const m=t?.maxChildLabelWidthRef.value;return m!==void 0?zt(m):void 0}if(t?.props.labelWidth!==void 0)return zt(t.props.labelWidth)}),i=I(()=>{const{labelAlign:v}=e;if(v)return v;if(t?.props.labelAlign)return t.props.labelAlign}),o=I(()=>{var v;return[(v=e.labelProps)===null||v===void 0?void 0:v.style,e.labelStyle,{width:a.value}]}),l=I(()=>{const{showRequireMark:v}=e;return v!==void 0?v:t?.props.showRequireMark}),s=I(()=>{const{requireMarkPlacement:v}=e;return v!==void 0?v:t?.props.requireMarkPlacement||"right"}),c=M(!1),u=M(!1),f=I(()=>{const{validationStatus:v}=e;if(v!==void 0)return v;if(c.value)return"error";if(u.value)return"warning"}),x=I(()=>{const{showFeedback:v}=e;return v!==void 0?v:t?.props.showFeedback!==void 0?t.props.showFeedback:!0}),S=I(()=>{const{showLabel:v}=e;return v!==void 0?v:t?.props.showLabel!==void 0?t.props.showLabel:!0});return{validationErrored:c,validationWarned:u,mergedLabelStyle:o,mergedLabelPlacement:r,mergedLabelAlign:i,mergedShowRequireMark:l,mergedRequireMarkPlacement:s,mergedValidationStatus:f,mergedShowFeedback:x,mergedShowLabel:S,isAutoLabelWidth:n}}function wo(e){const t=ze(ct,null),r=I(()=>{const{rulePath:o}=e;if(o!==void 0)return o;const{path:l}=e;if(l!==void 0)return l}),n=I(()=>{const o=[],{rule:l}=e;if(l!==void 0&&(Array.isArray(l)?o.push(...l):o.push(l)),t){const{rules:s}=t.props,{value:c}=r;if(s!==void 0&&c!==void 0){const u=Lr(s,c);u!==void 0&&(Array.isArray(u)?o.push(...u):o.push(u))}}return o}),a=I(()=>n.value.some(o=>o.required)),i=I(()=>a.value||e.required);return{mergedRules:n,mergedRequired:i}}var Pr=function(e,t,r,n){function a(i){return i instanceof r?i:new r(function(o){o(i)})}return new(r||(r=Promise))(function(i,o){function l(u){try{c(n.next(u))}catch(f){o(f)}}function s(u){try{c(n.throw(u))}catch(f){o(f)}}function c(u){u.done?i(u.value):a(u.value).then(l,s)}c((n=n.apply(e,t||[])).next())})};const So=Object.assign(Object.assign({},fe.props),{label:String,labelWidth:[Number,String],labelStyle:[String,Object],labelAlign:String,labelPlacement:String,path:String,first:Boolean,rulePath:String,required:Boolean,showRequireMark:{type:Boolean,default:void 0},requireMarkPlacement:String,showFeedback:{type:Boolean,default:void 0},rule:[Object,Array],size:String,ignorePathChange:Boolean,validationStatus:String,feedback:String,feedbackClass:String,feedbackStyle:[String,Object],showLabel:{type:Boolean,default:void 0},labelProps:Object,contentClass:String,contentStyle:[String,Object]});function _r(e,t){return(...r)=>{try{const n=e(...r);return!t&&(typeof n=="boolean"||n instanceof Error||Array.isArray(n))||n?.then?n:(n===void 0||Bt("form-item/validate",`You return a ${typeof n} typed value in the validator method, which is not recommended. Please use ${t?"`Promise`":"`boolean`, `Error` or `Promise`"} typed value instead.`),!0)}catch(n){Bt("form-item/validate","An error is catched in the validation, so the validation won't be done. Your callback in `validate` method of `n-form` or `n-form-item` won't be called in this validation."),console.error(n);return}}}const et=te({name:"FormItem",props:So,setup(e){Ca(Kr,"formItems",ie(e,"path"));const{mergedClsPrefixRef:t,inlineThemeDisabled:r}=Pe(e),n=ze(ct,null),a=yo(e),i=xo(e),{validationErrored:o,validationWarned:l}=i,{mergedRequired:s,mergedRules:c}=wo(e),{mergedSize:u}=a,{mergedLabelPlacement:f,mergedLabelAlign:x,mergedRequireMarkPlacement:S}=i,v=M([]),m=M(Ut()),y=n?ie(n.props,"disabled"):M(!1),b=fe("Form","-form-item",mo,Dr,e,t);He(ie(e,"path"),()=>{e.ignorePathChange||T()});function T(){v.value=[],o.value=!1,l.value=!1,e.feedback&&(m.value=Ut())}const R=(...B)=>Pr(this,[...B],void 0,function*(L=null,oe=()=>!0,J={suppressWarning:!0}){const{path:re}=e;J?J.first||(J.first=e.first):J={};const{value:me}=c,he=n?Lr(n.props.model,re||""):void 0,ne={},ce={},ye=(L?me.filter(X=>Array.isArray(X.trigger)?X.trigger.includes(L):X.trigger===L):me).filter(oe).map((X,le)=>{const Y=Object.assign({},X);if(Y.validator&&(Y.validator=_r(Y.validator,!1)),Y.asyncValidator&&(Y.asyncValidator=_r(Y.asyncValidator,!0)),Y.renderMessage){const Ce=`__renderMessage__${le}`;ce[Ce]=Y.message,Y.message=Ce,ne[Ce]=Y.renderMessage}return Y}),be=ye.filter(X=>X.level!=="warning"),ge=ye.filter(X=>X.level==="warning"),D={valid:!0,errors:void 0,warnings:void 0};if(!ye.length)return D;const ve=re??"__n_no_path__",pe=new Je({[ve]:be}),Te=new Je({[ve]:ge}),{validateMessages:xe}=n?.props||{};xe&&(pe.messages(xe),Te.messages(xe));const Fe=X=>{v.value=X.map(le=>{const Y=le?.message||"";return{key:Y,render:()=>Y.startsWith("__renderMessage__")?ne[Y]():Y}}),X.forEach(le=>{var Y;!((Y=le.message)===null||Y===void 0)&&Y.startsWith("__renderMessage__")&&(le.message=ce[le.message])})};if(be.length){const X=yield new Promise(le=>{pe.validate({[ve]:he},J,le)});X?.length&&(D.valid=!1,D.errors=X,Fe(X))}if(ge.length&&!D.errors){const X=yield new Promise(le=>{Te.validate({[ve]:he},J,le)});X?.length&&(Fe(X),D.warnings=X)}return!D.errors&&!D.warnings?T():(o.value=!!D.errors,l.value=!!D.warnings),D});function P(){R("blur")}function F(){R("change")}function k(){R("focus")}function V(){R("input")}function _(B,L){return Pr(this,void 0,void 0,function*(){let oe,J,re,me;return typeof B=="string"?(oe=B,J=L):B!==null&&typeof B=="object"&&(oe=B.trigger,J=B.callback,re=B.shouldRuleBeApplied,me=B.options),yield new Promise((he,ne)=>{R(oe,re,me).then(({valid:ce,errors:ye,warnings:be})=>{ce?(J&&J(void 0,{warnings:be}),he({warnings:be})):(J&&J(ye,{warnings:be}),ne(ye))})})})}Ge(Qn,{path:ie(e,"path"),disabled:y,mergedSize:a.mergedSize,mergedValidationStatus:i.mergedValidationStatus,restoreValidation:T,handleContentBlur:P,handleContentChange:F,handleContentFocus:k,handleContentInput:V});const O={validate:_,restoreValidation:T,internalValidate:R},N=M(null);rr(()=>{if(!i.isAutoLabelWidth.value)return;const B=N.value;if(B!==null){const L=B.style.whiteSpace;B.style.whiteSpace="nowrap",B.style.width="",n?.deriveMaxChildLabelWidth(Number(getComputedStyle(B).width.slice(0,-2))),B.style.whiteSpace=L}});const H=I(()=>{var B;const{value:L}=u,{value:oe}=f,J=oe==="top"?"vertical":"horizontal",{common:{cubicBezierEaseInOut:re},self:{labelTextColor:me,asteriskColor:he,lineHeight:ne,feedbackTextColor:ce,feedbackTextColorWarning:ye,feedbackTextColorError:be,feedbackPadding:ge,labelFontWeight:D,[Q("labelHeight",L)]:ve,[Q("blankHeight",L)]:pe,[Q("feedbackFontSize",L)]:Te,[Q("feedbackHeight",L)]:xe,[Q("labelPadding",J)]:Fe,[Q("labelTextAlign",J)]:X,[Q(Q("labelFontSize",oe),L)]:le}}=b.value;let Y=(B=x.value)!==null&&B!==void 0?B:X;return oe==="top"&&(Y=Y==="right"?"flex-end":"flex-start"),{"--n-bezier":re,"--n-line-height":ne,"--n-blank-height":pe,"--n-label-font-size":le,"--n-label-text-align":Y,"--n-label-height":ve,"--n-label-padding":Fe,"--n-label-font-weight":D,"--n-asterisk-color":he,"--n-label-text-color":me,"--n-feedback-padding":ge,"--n-feedback-font-size":Te,"--n-feedback-height":xe,"--n-feedback-text-color":ce,"--n-feedback-text-color-warning":ye,"--n-feedback-text-color-error":be}}),j=r?Le("form-item",I(()=>{var B;return`${u.value[0]}${f.value[0]}${((B=x.value)===null||B===void 0?void 0:B[0])||""}`}),H,e):void 0,G=I(()=>f.value==="left"&&S.value==="left"&&x.value==="left");return Object.assign(Object.assign(Object.assign(Object.assign({labelElementRef:N,mergedClsPrefix:t,mergedRequired:s,feedbackId:m,renderExplains:v,reverseColSpace:G},i),a),O),{cssVars:r?void 0:H,themeClass:j?.themeClass,onRender:j?.onRender})},render(){const{$slots:e,mergedClsPrefix:t,mergedShowLabel:r,mergedShowRequireMark:n,mergedRequireMarkPlacement:a,onRender:i}=this,o=n!==void 0?n:this.mergedRequired;i?.();const l=()=>{const s=this.$slots.label?this.$slots.label():this.label;if(!s)return null;const c=d("span",{class:`${t}-form-item-label__text`},s),u=o?d("span",{class:`${t}-form-item-label__asterisk`},a!=="left"?" *":"* "):a==="right-hanging"&&d("span",{class:`${t}-form-item-label__asterisk-placeholder`}," *"),{labelProps:f}=this;return d("label",Object.assign({},f,{class:[f?.class,`${t}-form-item-label`,`${t}-form-item-label--${a}-mark`,this.reverseColSpace&&`${t}-form-item-label--reverse-columns-space`],style:this.mergedLabelStyle,ref:"labelElementRef"}),a==="left"?[u,c]:[c,u])};return d("div",{class:[`${t}-form-item`,this.themeClass,`${t}-form-item--${this.mergedSize}-size`,`${t}-form-item--${this.mergedLabelPlacement}-labelled`,this.isAutoLabelWidth&&`${t}-form-item--auto-label-width`,!r&&`${t}-form-item--no-label`],style:this.cssVars},r&&l(),d("div",{class:[`${t}-form-item-blank`,this.contentClass,this.mergedValidationStatus&&`${t}-form-item-blank--${this.mergedValidationStatus}`],style:this.contentStyle},e),this.mergedShowFeedback?d("div",{key:this.feedbackId,style:this.feedbackStyle,class:[`${t}-form-item-feedback-wrapper`,this.feedbackClass]},d(Vr,{name:"fade-down-transition",mode:"out-in"},{default:()=>{const{mergedValidationStatus:s}=this;return Re(e.feedback,c=>{var u;const{feedback:f}=this,x=c||f?d("div",{key:"__feedback__",class:`${t}-form-item-feedback__line`},c||f):this.renderExplains.length?(u=this.renderExplains)===null||u===void 0?void 0:u.map(({key:S,render:v})=>d("div",{key:S,class:`${t}-form-item-feedback__line`},v())):null;return x?s==="warning"?d("div",{key:"controlled-warning",class:`${t}-form-item-feedback ${t}-form-item-feedback--warning`},x):s==="error"?d("div",{key:"controlled-error",class:`${t}-form-item-feedback ${t}-form-item-feedback--error`},x):s==="success"?d("div",{key:"controlled-success",class:`${t}-form-item-feedback ${t}-form-item-feedback--success`},x):d("div",{key:"controlled-default",class:`${t}-form-item-feedback`},x):null})}})):null)}}),ko=p("switch",`
 height: var(--n-height);
 min-width: var(--n-width);
 vertical-align: middle;
 user-select: none;
 -webkit-user-select: none;
 display: inline-flex;
 outline: none;
 justify-content: center;
 align-items: center;
`,[C("children-placeholder",`
 height: var(--n-rail-height);
 display: flex;
 flex-direction: column;
 overflow: hidden;
 pointer-events: none;
 visibility: hidden;
 `),C("rail-placeholder",`
 display: flex;
 flex-wrap: none;
 `),C("button-placeholder",`
 width: calc(1.75 * var(--n-rail-height));
 height: var(--n-rail-height);
 `),p("base-loading",`
 position: absolute;
 top: 50%;
 left: 50%;
 transform: translateX(-50%) translateY(-50%);
 font-size: calc(var(--n-button-width) - 4px);
 color: var(--n-loading-color);
 transition: color .3s var(--n-bezier);
 `,[fr({left:"50%",top:"50%",originalTransform:"translateX(-50%) translateY(-50%)"})]),C("checked, unchecked",`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 box-sizing: border-box;
 position: absolute;
 white-space: nowrap;
 top: 0;
 bottom: 0;
 display: flex;
 align-items: center;
 line-height: 1;
 `),C("checked",`
 right: 0;
 padding-right: calc(1.25 * var(--n-rail-height) - var(--n-offset));
 `),C("unchecked",`
 left: 0;
 justify-content: flex-end;
 padding-left: calc(1.25 * var(--n-rail-height) - var(--n-offset));
 `),U("&:focus",[C("rail",`
 box-shadow: var(--n-box-shadow-focus);
 `)]),$("round",[C("rail","border-radius: calc(var(--n-rail-height) / 2);",[C("button","border-radius: calc(var(--n-button-height) / 2);")])]),je("disabled",[je("icon",[$("rubber-band",[$("pressed",[C("rail",[C("button","max-width: var(--n-button-width-pressed);")])]),C("rail",[U("&:active",[C("button","max-width: var(--n-button-width-pressed);")])]),$("active",[$("pressed",[C("rail",[C("button","left: calc(100% - var(--n-offset) - var(--n-button-width-pressed));")])]),C("rail",[U("&:active",[C("button","left: calc(100% - var(--n-offset) - var(--n-button-width-pressed));")])])])])])]),$("active",[C("rail",[C("button","left: calc(100% - var(--n-button-width) - var(--n-offset))")])]),C("rail",`
 overflow: hidden;
 height: var(--n-rail-height);
 min-width: var(--n-rail-width);
 border-radius: var(--n-rail-border-radius);
 cursor: pointer;
 position: relative;
 transition:
 opacity .3s var(--n-bezier),
 background .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 background-color: var(--n-rail-color);
 `,[C("button-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 font-size: calc(var(--n-button-height) - 4px);
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 display: flex;
 justify-content: center;
 align-items: center;
 line-height: 1;
 `,[fr()]),C("button",`
 align-items: center; 
 top: var(--n-offset);
 left: var(--n-offset);
 height: var(--n-button-height);
 width: var(--n-button-width-pressed);
 max-width: var(--n-button-width);
 border-radius: var(--n-button-border-radius);
 background-color: var(--n-button-color);
 box-shadow: var(--n-button-box-shadow);
 box-sizing: border-box;
 cursor: inherit;
 content: "";
 position: absolute;
 transition:
 background-color .3s var(--n-bezier),
 left .3s var(--n-bezier),
 opacity .3s var(--n-bezier),
 max-width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 `)]),$("active",[C("rail","background-color: var(--n-rail-color-active);")]),$("loading",[C("rail",`
 cursor: wait;
 `)]),$("disabled",[C("rail",`
 cursor: not-allowed;
 opacity: .5;
 `)])]),Co=Object.assign(Object.assign({},fe.props),{size:{type:String,default:"medium"},value:{type:[String,Number,Boolean],default:void 0},loading:Boolean,defaultValue:{type:[String,Number,Boolean],default:!1},disabled:{type:Boolean,default:void 0},round:{type:Boolean,default:!0},"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],checkedValue:{type:[String,Number,Boolean],default:!0},uncheckedValue:{type:[String,Number,Boolean],default:!1},railStyle:Function,rubberBand:{type:Boolean,default:!0},onChange:[Function,Array]});let tt;const Xr=te({name:"Switch",props:Co,slots:Object,setup(e){tt===void 0&&(typeof CSS<"u"?typeof CSS.supports<"u"?tt=CSS.supports("width","max(1px)"):tt=!1:tt=!0);const{mergedClsPrefixRef:t,inlineThemeDisabled:r}=Pe(e),n=fe("Switch","-switch",ko,ra,e,t),a=ir(e),{mergedSizeRef:i,mergedDisabledRef:o}=a,l=M(e.defaultValue),s=ie(e,"value"),c=Xe(s,l),u=I(()=>c.value===e.checkedValue),f=M(!1),x=M(!1),S=I(()=>{const{railStyle:_}=e;if(_)return _({focused:x.value,checked:u.value})});function v(_){const{"onUpdate:value":O,onChange:N,onUpdateValue:H}=e,{nTriggerFormInput:j,nTriggerFormChange:G}=a;O&&ue(O,_),H&&ue(H,_),N&&ue(N,_),l.value=_,j(),G()}function m(){const{nTriggerFormFocus:_}=a;_()}function y(){const{nTriggerFormBlur:_}=a;_()}function b(){e.loading||o.value||(c.value!==e.checkedValue?v(e.checkedValue):v(e.uncheckedValue))}function T(){x.value=!0,m()}function R(){x.value=!1,y(),f.value=!1}function P(_){e.loading||o.value||_.key===" "&&(c.value!==e.checkedValue?v(e.checkedValue):v(e.uncheckedValue),f.value=!1)}function F(_){e.loading||o.value||_.key===" "&&(_.preventDefault(),f.value=!0)}const k=I(()=>{const{value:_}=i,{self:{opacityDisabled:O,railColor:N,railColorActive:H,buttonBoxShadow:j,buttonColor:G,boxShadowFocus:B,loadingColor:L,textColor:oe,iconColor:J,[Q("buttonHeight",_)]:re,[Q("buttonWidth",_)]:me,[Q("buttonWidthPressed",_)]:he,[Q("railHeight",_)]:ne,[Q("railWidth",_)]:ce,[Q("railBorderRadius",_)]:ye,[Q("buttonBorderRadius",_)]:be},common:{cubicBezierEaseInOut:ge}}=n.value;let D,ve,pe;return tt?(D=`calc((${ne} - ${re}) / 2)`,ve=`max(${ne}, ${re})`,pe=`max(${ce}, calc(${ce} + ${re} - ${ne}))`):(D=_t((Se(ne)-Se(re))/2),ve=_t(Math.max(Se(ne),Se(re))),pe=Se(ne)>Se(re)?ce:_t(Se(ce)+Se(re)-Se(ne))),{"--n-bezier":ge,"--n-button-border-radius":be,"--n-button-box-shadow":j,"--n-button-color":G,"--n-button-width":me,"--n-button-width-pressed":he,"--n-button-height":re,"--n-height":ve,"--n-offset":D,"--n-opacity-disabled":O,"--n-rail-border-radius":ye,"--n-rail-color":N,"--n-rail-color-active":H,"--n-rail-height":ne,"--n-rail-width":ce,"--n-width":pe,"--n-box-shadow-focus":B,"--n-loading-color":L,"--n-text-color":oe,"--n-icon-color":J}}),V=r?Le("switch",I(()=>i.value[0]),k,e):void 0;return{handleClick:b,handleBlur:R,handleFocus:T,handleKeyup:P,handleKeydown:F,mergedRailStyle:S,pressed:f,mergedClsPrefix:t,mergedValue:c,checked:u,mergedDisabled:o,cssVars:r?void 0:k,themeClass:V?.themeClass,onRender:V?.onRender}},render(){const{mergedClsPrefix:e,mergedDisabled:t,checked:r,mergedRailStyle:n,onRender:a,$slots:i}=this;a?.();const{checked:o,unchecked:l,icon:s,"checked-icon":c,"unchecked-icon":u}=i,f=!(Pt(s)&&Pt(c)&&Pt(u));return d("div",{role:"switch","aria-checked":r,class:[`${e}-switch`,this.themeClass,f&&`${e}-switch--icon`,r&&`${e}-switch--active`,t&&`${e}-switch--disabled`,this.round&&`${e}-switch--round`,this.loading&&`${e}-switch--loading`,this.pressed&&`${e}-switch--pressed`,this.rubberBand&&`${e}-switch--rubber-band`],tabindex:this.mergedDisabled?void 0:0,style:this.cssVars,onClick:this.handleClick,onFocus:this.handleFocus,onBlur:this.handleBlur,onKeyup:this.handleKeyup,onKeydown:this.handleKeydown},d("div",{class:`${e}-switch__rail`,"aria-hidden":"true",style:n},Re(o,x=>Re(l,S=>x||S?d("div",{"aria-hidden":!0,class:`${e}-switch__children-placeholder`},d("div",{class:`${e}-switch__rail-placeholder`},d("div",{class:`${e}-switch__button-placeholder`}),x),d("div",{class:`${e}-switch__rail-placeholder`},d("div",{class:`${e}-switch__button-placeholder`}),S)):null)),d("div",{class:`${e}-switch__button`},Re(s,x=>Re(c,S=>Re(u,v=>d(ea,null,{default:()=>this.loading?d(ta,{key:"loading",clsPrefix:e,strokeWidth:20}):this.checked&&(S||x)?d("div",{class:`${e}-switch__button-icon`,key:S?"checked-icon":"icon"},S||x):!this.checked&&(v||x)?d("div",{class:`${e}-switch__button-icon`,key:v?"unchecked-icon":"icon"},v||x):null})))),Re(o,x=>x&&d("div",{key:"checked",class:`${e}-switch__checked`},x)),Re(l,x=>x&&d("div",{key:"unchecked",class:`${e}-switch__unchecked`},x)))))}}),lr=dt("n-tabs"),Yr={tab:[String,Number,Object,Function],name:{type:[String,Number],required:!0},disabled:Boolean,displayDirective:{type:String,default:"if"},closable:{type:Boolean,default:void 0},tabProps:Object,label:[String,Number,Object,Function]},Ar=te({__TAB_PANE__:!0,name:"TabPane",alias:["TabPanel"],props:Yr,slots:Object,setup(e){const t=ze(lr,null);return t||Ir("tab-pane","`n-tab-pane` must be placed inside `n-tabs`."),{style:t.paneStyleRef,class:t.paneClassRef,mergedClsPrefix:t.mergedClsPrefixRef}},render(){return d("div",{class:[`${this.mergedClsPrefix}-tab-pane`,this.class],style:this.style},this.$slots)}}),Ro=Object.assign({internalLeftPadded:Boolean,internalAddable:Boolean,internalCreatedByPane:Boolean},ia(Yr,["displayDirective"])),Qt=te({__TAB__:!0,inheritAttrs:!1,name:"Tab",props:Ro,setup(e){const{mergedClsPrefixRef:t,valueRef:r,typeRef:n,closableRef:a,tabStyleRef:i,addTabStyleRef:o,tabClassRef:l,addTabClassRef:s,tabChangeIdRef:c,onBeforeLeaveRef:u,triggerRef:f,handleAdd:x,activateTab:S,handleClose:v}=ze(lr);return{trigger:f,mergedClosable:I(()=>{if(e.internalAddable)return!1;const{closable:m}=e;return m===void 0?a.value:m}),style:i,addStyle:o,tabClass:l,addTabClass:s,clsPrefix:t,value:r,type:n,handleClose(m){m.stopPropagation(),!e.disabled&&v(e.name)},activateTab(){if(e.disabled)return;if(e.internalAddable){x();return}const{name:m}=e,y=++c.id;if(m!==r.value){const{value:b}=u;b?Promise.resolve(b(e.name,r.value)).then(T=>{T&&c.id===y&&S(m)}):S(m)}}}},render(){const{internalAddable:e,clsPrefix:t,name:r,disabled:n,label:a,tab:i,value:o,mergedClosable:l,trigger:s,$slots:{default:c}}=this,u=a??i;return d("div",{class:`${t}-tabs-tab-wrapper`},this.internalLeftPadded?d("div",{class:`${t}-tabs-tab-pad`}):null,d("div",Object.assign({key:r,"data-name":r,"data-disabled":n?!0:void 0},$n({class:[`${t}-tabs-tab`,o===r&&`${t}-tabs-tab--active`,n&&`${t}-tabs-tab--disabled`,l&&`${t}-tabs-tab--closable`,e&&`${t}-tabs-tab--addable`,e?this.addTabClass:this.tabClass],onClick:s==="click"?this.activateTab:void 0,onMouseenter:s==="hover"?this.activateTab:void 0,style:e?this.addStyle:this.style},this.internalCreatedByPane?this.tabProps||{}:this.$attrs)),d("span",{class:`${t}-tabs-tab__label`},e?d(Ct,null,d("div",{class:`${t}-tabs-tab__height-placeholder`}," "),d(ar,{clsPrefix:t},{default:()=>d(Nr,null)})):c?c():typeof u=="object"?u:na(u??r)),l&&this.type==="card"?d(aa,{clsPrefix:t,class:`${t}-tabs-tab__close`,onClick:this.handleClose,disabled:n}):null))}}),$o=p("tabs",`
 box-sizing: border-box;
 width: 100%;
 display: flex;
 flex-direction: column;
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
`,[$("segment-type",[p("tabs-rail",[U("&.transition-disabled",[p("tabs-capsule",`
 transition: none;
 `)])])]),$("top",[p("tab-pane",`
 padding: var(--n-pane-padding-top) var(--n-pane-padding-right) var(--n-pane-padding-bottom) var(--n-pane-padding-left);
 `)]),$("left",[p("tab-pane",`
 padding: var(--n-pane-padding-right) var(--n-pane-padding-bottom) var(--n-pane-padding-left) var(--n-pane-padding-top);
 `)]),$("left, right",`
 flex-direction: row;
 `,[p("tabs-bar",`
 width: 2px;
 right: 0;
 transition:
 top .2s var(--n-bezier),
 max-height .2s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `),p("tabs-tab",`
 padding: var(--n-tab-padding-vertical); 
 `)]),$("right",`
 flex-direction: row-reverse;
 `,[p("tab-pane",`
 padding: var(--n-pane-padding-left) var(--n-pane-padding-top) var(--n-pane-padding-right) var(--n-pane-padding-bottom);
 `),p("tabs-bar",`
 left: 0;
 `)]),$("bottom",`
 flex-direction: column-reverse;
 justify-content: flex-end;
 `,[p("tab-pane",`
 padding: var(--n-pane-padding-bottom) var(--n-pane-padding-right) var(--n-pane-padding-top) var(--n-pane-padding-left);
 `),p("tabs-bar",`
 top: 0;
 `)]),p("tabs-rail",`
 position: relative;
 padding: 3px;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 background-color: var(--n-color-segment);
 transition: background-color .3s var(--n-bezier);
 display: flex;
 align-items: center;
 `,[p("tabs-capsule",`
 border-radius: var(--n-tab-border-radius);
 position: absolute;
 pointer-events: none;
 background-color: var(--n-tab-color-segment);
 box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .08);
 transition: transform 0.3s var(--n-bezier);
 `),p("tabs-tab-wrapper",`
 flex-basis: 0;
 flex-grow: 1;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[p("tabs-tab",`
 overflow: hidden;
 border-radius: var(--n-tab-border-radius);
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `,[$("active",`
 font-weight: var(--n-font-weight-strong);
 color: var(--n-tab-text-color-active);
 `),U("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])])]),$("flex",[p("tabs-nav",`
 width: 100%;
 position: relative;
 `,[p("tabs-wrapper",`
 width: 100%;
 `,[p("tabs-tab",`
 margin-right: 0;
 `)])])]),p("tabs-nav",`
 box-sizing: border-box;
 line-height: 1.5;
 display: flex;
 transition: border-color .3s var(--n-bezier);
 `,[C("prefix, suffix",`
 display: flex;
 align-items: center;
 `),C("prefix","padding-right: 16px;"),C("suffix","padding-left: 16px;")]),$("top, bottom",[U(">",[p("tabs-nav",[p("tabs-nav-scroll-wrapper",[U("&::before",`
 top: 0;
 bottom: 0;
 left: 0;
 width: 20px;
 `),U("&::after",`
 top: 0;
 bottom: 0;
 right: 0;
 width: 20px;
 `),$("shadow-start",[U("&::before",`
 box-shadow: inset 10px 0 8px -8px rgba(0, 0, 0, .12);
 `)]),$("shadow-end",[U("&::after",`
 box-shadow: inset -10px 0 8px -8px rgba(0, 0, 0, .12);
 `)])])])])]),$("left, right",[p("tabs-nav-scroll-content",`
 flex-direction: column;
 `),U(">",[p("tabs-nav",[p("tabs-nav-scroll-wrapper",[U("&::before",`
 top: 0;
 left: 0;
 right: 0;
 height: 20px;
 `),U("&::after",`
 bottom: 0;
 left: 0;
 right: 0;
 height: 20px;
 `),$("shadow-start",[U("&::before",`
 box-shadow: inset 0 10px 8px -8px rgba(0, 0, 0, .12);
 `)]),$("shadow-end",[U("&::after",`
 box-shadow: inset 0 -10px 8px -8px rgba(0, 0, 0, .12);
 `)])])])])]),p("tabs-nav-scroll-wrapper",`
 flex: 1;
 position: relative;
 overflow: hidden;
 `,[p("tabs-nav-y-scroll",`
 height: 100%;
 width: 100%;
 overflow-y: auto; 
 scrollbar-width: none;
 `,[U("&::-webkit-scrollbar, &::-webkit-scrollbar-track-piece, &::-webkit-scrollbar-thumb",`
 width: 0;
 height: 0;
 display: none;
 `)]),U("&::before, &::after",`
 transition: box-shadow .3s var(--n-bezier);
 pointer-events: none;
 content: "";
 position: absolute;
 z-index: 1;
 `)]),p("tabs-nav-scroll-content",`
 display: flex;
 position: relative;
 min-width: 100%;
 min-height: 100%;
 width: fit-content;
 box-sizing: border-box;
 `),p("tabs-wrapper",`
 display: inline-flex;
 flex-wrap: nowrap;
 position: relative;
 `),p("tabs-tab-wrapper",`
 display: flex;
 flex-wrap: nowrap;
 flex-shrink: 0;
 flex-grow: 0;
 `),p("tabs-tab",`
 cursor: pointer;
 white-space: nowrap;
 flex-wrap: nowrap;
 display: inline-flex;
 align-items: center;
 color: var(--n-tab-text-color);
 font-size: var(--n-tab-font-size);
 background-clip: padding-box;
 padding: var(--n-tab-padding);
 transition:
 box-shadow .3s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[$("disabled",{cursor:"not-allowed"}),C("close",`
 margin-left: 6px;
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `),C("label",`
 display: flex;
 align-items: center;
 z-index: 1;
 `)]),p("tabs-bar",`
 position: absolute;
 bottom: 0;
 height: 2px;
 border-radius: 1px;
 background-color: var(--n-bar-color);
 transition:
 left .2s var(--n-bezier),
 max-width .2s var(--n-bezier),
 opacity .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `,[U("&.transition-disabled",`
 transition: none;
 `),$("disabled",`
 background-color: var(--n-tab-text-color-disabled)
 `)]),p("tabs-pane-wrapper",`
 position: relative;
 overflow: hidden;
 transition: max-height .2s var(--n-bezier);
 `),p("tab-pane",`
 color: var(--n-pane-text-color);
 width: 100%;
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 opacity .2s var(--n-bezier);
 left: 0;
 right: 0;
 top: 0;
 `,[U("&.next-transition-leave-active, &.prev-transition-leave-active, &.next-transition-enter-active, &.prev-transition-enter-active",`
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 transform .2s var(--n-bezier),
 opacity .2s var(--n-bezier);
 `),U("&.next-transition-leave-active, &.prev-transition-leave-active",`
 position: absolute;
 `),U("&.next-transition-enter-from, &.prev-transition-leave-to",`
 transform: translateX(32px);
 opacity: 0;
 `),U("&.next-transition-leave-to, &.prev-transition-enter-from",`
 transform: translateX(-32px);
 opacity: 0;
 `),U("&.next-transition-leave-from, &.next-transition-enter-to, &.prev-transition-leave-from, &.prev-transition-enter-to",`
 transform: translateX(0);
 opacity: 1;
 `)]),p("tabs-tab-pad",`
 box-sizing: border-box;
 width: var(--n-tab-gap);
 flex-grow: 0;
 flex-shrink: 0;
 `),$("line-type, bar-type",[p("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 box-sizing: border-box;
 vertical-align: bottom;
 `,[U("&:hover",{color:"var(--n-tab-text-color-hover)"}),$("active",`
 color: var(--n-tab-text-color-active);
 font-weight: var(--n-tab-font-weight-active);
 `),$("disabled",{color:"var(--n-tab-text-color-disabled)"})])]),p("tabs-nav",[$("line-type",[$("top",[C("prefix, suffix",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),p("tabs-nav-scroll-content",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),p("tabs-bar",`
 bottom: -1px;
 `)]),$("left",[C("prefix, suffix",`
 border-right: 1px solid var(--n-tab-border-color);
 `),p("tabs-nav-scroll-content",`
 border-right: 1px solid var(--n-tab-border-color);
 `),p("tabs-bar",`
 right: -1px;
 `)]),$("right",[C("prefix, suffix",`
 border-left: 1px solid var(--n-tab-border-color);
 `),p("tabs-nav-scroll-content",`
 border-left: 1px solid var(--n-tab-border-color);
 `),p("tabs-bar",`
 left: -1px;
 `)]),$("bottom",[C("prefix, suffix",`
 border-top: 1px solid var(--n-tab-border-color);
 `),p("tabs-nav-scroll-content",`
 border-top: 1px solid var(--n-tab-border-color);
 `),p("tabs-bar",`
 top: -1px;
 `)]),C("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 `),p("tabs-nav-scroll-content",`
 transition: border-color .3s var(--n-bezier);
 `),p("tabs-bar",`
 border-radius: 0;
 `)]),$("card-type",[C("prefix, suffix",`
 transition: border-color .3s var(--n-bezier);
 `),p("tabs-pad",`
 flex-grow: 1;
 transition: border-color .3s var(--n-bezier);
 `),p("tabs-tab-pad",`
 transition: border-color .3s var(--n-bezier);
 `),p("tabs-tab",`
 font-weight: var(--n-tab-font-weight);
 border: 1px solid var(--n-tab-border-color);
 background-color: var(--n-tab-color);
 box-sizing: border-box;
 position: relative;
 vertical-align: bottom;
 display: flex;
 justify-content: space-between;
 font-size: var(--n-tab-font-size);
 color: var(--n-tab-text-color);
 `,[$("addable",`
 padding-left: 8px;
 padding-right: 8px;
 font-size: 16px;
 justify-content: center;
 `,[C("height-placeholder",`
 width: 0;
 font-size: var(--n-tab-font-size);
 `),je("disabled",[U("&:hover",`
 color: var(--n-tab-text-color-hover);
 `)])]),$("closable","padding-right: 8px;"),$("active",`
 background-color: #0000;
 font-weight: var(--n-tab-font-weight-active);
 color: var(--n-tab-text-color-active);
 `),$("disabled","color: var(--n-tab-text-color-disabled);")])]),$("left, right",`
 flex-direction: column; 
 `,[C("prefix, suffix",`
 padding: var(--n-tab-padding-vertical);
 `),p("tabs-wrapper",`
 flex-direction: column;
 `),p("tabs-tab-wrapper",`
 flex-direction: column;
 `,[p("tabs-tab-pad",`
 height: var(--n-tab-gap-vertical);
 width: 100%;
 `)])]),$("top",[$("card-type",[p("tabs-scroll-padding","border-bottom: 1px solid var(--n-tab-border-color);"),C("prefix, suffix",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),p("tabs-tab",`
 border-top-left-radius: var(--n-tab-border-radius);
 border-top-right-radius: var(--n-tab-border-radius);
 `,[$("active",`
 border-bottom: 1px solid #0000;
 `)]),p("tabs-tab-pad",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `),p("tabs-pad",`
 border-bottom: 1px solid var(--n-tab-border-color);
 `)])]),$("left",[$("card-type",[p("tabs-scroll-padding","border-right: 1px solid var(--n-tab-border-color);"),C("prefix, suffix",`
 border-right: 1px solid var(--n-tab-border-color);
 `),p("tabs-tab",`
 border-top-left-radius: var(--n-tab-border-radius);
 border-bottom-left-radius: var(--n-tab-border-radius);
 `,[$("active",`
 border-right: 1px solid #0000;
 `)]),p("tabs-tab-pad",`
 border-right: 1px solid var(--n-tab-border-color);
 `),p("tabs-pad",`
 border-right: 1px solid var(--n-tab-border-color);
 `)])]),$("right",[$("card-type",[p("tabs-scroll-padding","border-left: 1px solid var(--n-tab-border-color);"),C("prefix, suffix",`
 border-left: 1px solid var(--n-tab-border-color);
 `),p("tabs-tab",`
 border-top-right-radius: var(--n-tab-border-radius);
 border-bottom-right-radius: var(--n-tab-border-radius);
 `,[$("active",`
 border-left: 1px solid #0000;
 `)]),p("tabs-tab-pad",`
 border-left: 1px solid var(--n-tab-border-color);
 `),p("tabs-pad",`
 border-left: 1px solid var(--n-tab-border-color);
 `)])]),$("bottom",[$("card-type",[p("tabs-scroll-padding","border-top: 1px solid var(--n-tab-border-color);"),C("prefix, suffix",`
 border-top: 1px solid var(--n-tab-border-color);
 `),p("tabs-tab",`
 border-bottom-left-radius: var(--n-tab-border-radius);
 border-bottom-right-radius: var(--n-tab-border-radius);
 `,[$("active",`
 border-top: 1px solid #0000;
 `)]),p("tabs-tab-pad",`
 border-top: 1px solid var(--n-tab-border-color);
 `),p("tabs-pad",`
 border-top: 1px solid var(--n-tab-border-color);
 `)])])])]),It=La,zo=Object.assign(Object.assign({},fe.props),{value:[String,Number],defaultValue:[String,Number],trigger:{type:String,default:"click"},type:{type:String,default:"bar"},closable:Boolean,justifyContent:String,size:{type:String,default:"medium"},placement:{type:String,default:"top"},tabStyle:[String,Object],tabClass:String,addTabStyle:[String,Object],addTabClass:String,barWidth:Number,paneClass:String,paneStyle:[String,Object],paneWrapperClass:String,paneWrapperStyle:[String,Object],addable:[Boolean,Object],tabsPadding:{type:Number,default:0},animated:Boolean,onBeforeLeave:Function,onAdd:Function,"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],onClose:[Function,Array],labelSize:String,activeName:[String,Number],onActiveNameChange:[Function,Array]}),Po=te({name:"Tabs",props:zo,slots:Object,setup(e,{slots:t}){var r,n,a,i;const{mergedClsPrefixRef:o,inlineThemeDisabled:l}=Pe(e),s=fe("Tabs","-tabs",$o,oa,e,o),c=M(null),u=M(null),f=M(null),x=M(null),S=M(null),v=M(null),m=M(!0),y=M(!0),b=vr(e,["labelSize","size"]),T=vr(e,["activeName","value"]),R=M((n=(r=T.value)!==null&&r!==void 0?r:e.defaultValue)!==null&&n!==void 0?n:t.default?(i=(a=xt(t.default())[0])===null||a===void 0?void 0:a.props)===null||i===void 0?void 0:i.name:null),P=Xe(T,R),F={id:0},k=I(()=>{if(!(!e.justifyContent||e.type==="card"))return{display:"flex",justifyContent:e.justifyContent}});He(P,()=>{F.id=0,H(),j()});function V(){var h;const{value:g}=P;return g===null?null:(h=c.value)===null||h===void 0?void 0:h.querySelector(`[data-name="${g}"]`)}function _(h){if(e.type==="card")return;const{value:g}=u;if(!g)return;const z=g.style.opacity==="0";if(h){const E=`${o.value}-tabs-bar--disabled`,{barWidth:K,placement:ee}=e;if(h.dataset.disabled==="true"?g.classList.add(E):g.classList.remove(E),["top","bottom"].includes(ee)){if(N(["top","maxHeight","height"]),typeof K=="number"&&h.offsetWidth>=K){const se=Math.floor((h.offsetWidth-K)/2)+h.offsetLeft;g.style.left=`${se}px`,g.style.maxWidth=`${K}px`}else g.style.left=`${h.offsetLeft}px`,g.style.maxWidth=`${h.offsetWidth}px`;g.style.width="8192px",z&&(g.style.transition="none"),g.offsetWidth,z&&(g.style.transition="",g.style.opacity="1")}else{if(N(["left","maxWidth","width"]),typeof K=="number"&&h.offsetHeight>=K){const se=Math.floor((h.offsetHeight-K)/2)+h.offsetTop;g.style.top=`${se}px`,g.style.maxHeight=`${K}px`}else g.style.top=`${h.offsetTop}px`,g.style.maxHeight=`${h.offsetHeight}px`;g.style.height="8192px",z&&(g.style.transition="none"),g.offsetHeight,z&&(g.style.transition="",g.style.opacity="1")}}}function O(){if(e.type==="card")return;const{value:h}=u;h&&(h.style.opacity="0")}function N(h){const{value:g}=u;if(g)for(const z of h)g.style[z]=""}function H(){if(e.type==="card")return;const h=V();h?_(h):O()}function j(){var h;const g=(h=S.value)===null||h===void 0?void 0:h.$el;if(!g)return;const z=V();if(!z)return;const{scrollLeft:E,offsetWidth:K}=g,{offsetLeft:ee,offsetWidth:se}=z;E>ee?g.scrollTo({top:0,left:ee,behavior:"smooth"}):ee+se>E+K&&g.scrollTo({top:0,left:ee+se-K,behavior:"smooth"})}const G=M(null);let B=0,L=null;function oe(h){const g=G.value;if(g){B=h.getBoundingClientRect().height;const z=`${B}px`,E=()=>{g.style.height=z,g.style.maxHeight=z};L?(E(),L(),L=null):L=E}}function J(h){const g=G.value;if(g){const z=h.getBoundingClientRect().height,E=()=>{document.body.offsetHeight,g.style.maxHeight=`${z}px`,g.style.height=`${Math.max(B,z)}px`};L?(L(),L=null,E()):L=E}}function re(){const h=G.value;if(h){h.style.maxHeight="",h.style.height="";const{paneWrapperStyle:g}=e;if(typeof g=="string")h.style.cssText=g;else if(g){const{maxHeight:z,height:E}=g;z!==void 0&&(h.style.maxHeight=z),E!==void 0&&(h.style.height=E)}}}const me={value:[]},he=M("next");function ne(h){const g=P.value;let z="next";for(const E of me.value){if(E===g)break;if(E===h){z="prev";break}}he.value=z,ce(h)}function ce(h){const{onActiveNameChange:g,onUpdateValue:z,"onUpdate:value":E}=e;g&&ue(g,h),z&&ue(z,h),E&&ue(E,h),R.value=h}function ye(h){const{onClose:g}=e;g&&ue(g,h)}function be(){const{value:h}=u;if(!h)return;const g="transition-disabled";h.classList.add(g),H(),h.classList.remove(g)}const ge=M(null);function D({transitionDisabled:h}){const g=c.value;if(!g)return;h&&g.classList.add("transition-disabled");const z=V();z&&ge.value&&(ge.value.style.width=`${z.offsetWidth}px`,ge.value.style.height=`${z.offsetHeight}px`,ge.value.style.transform=`translateX(${z.offsetLeft-Se(getComputedStyle(g).paddingLeft)}px)`,h&&ge.value.offsetWidth),h&&g.classList.remove("transition-disabled")}He([P],()=>{e.type==="segment"&&at(()=>{D({transitionDisabled:!1})})}),rr(()=>{e.type==="segment"&&D({transitionDisabled:!0})});let ve=0;function pe(h){var g;if(h.contentRect.width===0&&h.contentRect.height===0||ve===h.contentRect.width)return;ve=h.contentRect.width;const{type:z}=e;if((z==="line"||z==="bar")&&be(),z!=="segment"){const{placement:E}=e;Y((E==="top"||E==="bottom"?(g=S.value)===null||g===void 0?void 0:g.$el:v.value)||null)}}const Te=It(pe,64);He([()=>e.justifyContent,()=>e.size],()=>{at(()=>{const{type:h}=e;(h==="line"||h==="bar")&&be()})});const xe=M(!1);function Fe(h){var g;const{target:z,contentRect:{width:E,height:K}}=h,ee=z.parentElement.parentElement.offsetWidth,se=z.parentElement.parentElement.offsetHeight,{placement:Ee}=e;if(!xe.value)Ee==="top"||Ee==="bottom"?ee<E&&(xe.value=!0):se<K&&(xe.value=!0);else{const{value:Ve}=x;if(!Ve)return;Ee==="top"||Ee==="bottom"?ee-E>Ve.$el.offsetWidth&&(xe.value=!1):se-K>Ve.$el.offsetHeight&&(xe.value=!1)}Y(((g=S.value)===null||g===void 0?void 0:g.$el)||null)}const X=It(Fe,64);function le(){const{onAdd:h}=e;h&&h(),at(()=>{const g=V(),{value:z}=S;!g||!z||z.scrollTo({left:g.offsetLeft,top:0,behavior:"smooth"})})}function Y(h){if(!h)return;const{placement:g}=e;if(g==="top"||g==="bottom"){const{scrollLeft:z,scrollWidth:E,offsetWidth:K}=h;m.value=z<=0,y.value=z+K>=E}else{const{scrollTop:z,scrollHeight:E,offsetHeight:K}=h;m.value=z<=0,y.value=z+K>=E}}const Ce=It(h=>{Y(h.target)},64);Ge(lr,{triggerRef:ie(e,"trigger"),tabStyleRef:ie(e,"tabStyle"),tabClassRef:ie(e,"tabClass"),addTabStyleRef:ie(e,"addTabStyle"),addTabClassRef:ie(e,"addTabClass"),paneClassRef:ie(e,"paneClass"),paneStyleRef:ie(e,"paneStyle"),mergedClsPrefixRef:o,typeRef:ie(e,"type"),closableRef:ie(e,"closable"),valueRef:P,tabChangeIdRef:F,onBeforeLeaveRef:ie(e,"onBeforeLeave"),activateTab:ne,handleClose:ye,handleAdd:le}),Sa(()=>{H(),j()}),tr(()=>{const{value:h}=f;if(!h)return;const{value:g}=o,z=`${g}-tabs-nav-scroll-wrapper--shadow-start`,E=`${g}-tabs-nav-scroll-wrapper--shadow-end`;m.value?h.classList.remove(z):h.classList.add(z),y.value?h.classList.remove(E):h.classList.add(E)});const ke={syncBarPosition:()=>{H()}},$t=()=>{D({transitionDisabled:!0})},w=I(()=>{const{value:h}=b,{type:g}=e,z={card:"Card",bar:"Bar",line:"Line",segment:"Segment"}[g],E=`${h}${z}`,{self:{barColor:K,closeIconColor:ee,closeIconColorHover:se,closeIconColorPressed:Ee,tabColor:Ve,tabBorderColor:Zr,paneTextColor:Jr,tabFontWeight:Qr,tabBorderRadius:en,tabFontWeightActive:tn,colorSegment:rn,fontWeightStrong:nn,tabColorSegment:an,closeSize:on,closeIconSize:ln,closeColorHover:sn,closeColorPressed:dn,closeBorderRadius:cn,[Q("panePadding",h)]:ut,[Q("tabPadding",E)]:un,[Q("tabPaddingVertical",E)]:fn,[Q("tabGap",E)]:pn,[Q("tabGap",`${E}Vertical`)]:hn,[Q("tabTextColor",g)]:bn,[Q("tabTextColorActive",g)]:gn,[Q("tabTextColorHover",g)]:vn,[Q("tabTextColorDisabled",g)]:mn,[Q("tabFontSize",h)]:yn},common:{cubicBezierEaseInOut:xn}}=s.value;return{"--n-bezier":xn,"--n-color-segment":rn,"--n-bar-color":K,"--n-tab-font-size":yn,"--n-tab-text-color":bn,"--n-tab-text-color-active":gn,"--n-tab-text-color-disabled":mn,"--n-tab-text-color-hover":vn,"--n-pane-text-color":Jr,"--n-tab-border-color":Zr,"--n-tab-border-radius":en,"--n-close-size":on,"--n-close-icon-size":ln,"--n-close-color-hover":sn,"--n-close-color-pressed":dn,"--n-close-border-radius":cn,"--n-close-icon-color":ee,"--n-close-icon-color-hover":se,"--n-close-icon-color-pressed":Ee,"--n-tab-color":Ve,"--n-tab-font-weight":Qr,"--n-tab-font-weight-active":tn,"--n-tab-padding":un,"--n-tab-padding-vertical":fn,"--n-tab-gap":pn,"--n-tab-gap-vertical":hn,"--n-pane-padding-left":ft(ut,"left"),"--n-pane-padding-right":ft(ut,"right"),"--n-pane-padding-top":ft(ut,"top"),"--n-pane-padding-bottom":ft(ut,"bottom"),"--n-font-weight-strong":nn,"--n-tab-color-segment":an}}),q=l?Le("tabs",I(()=>`${b.value[0]}${e.type[0]}`),w,e):void 0;return Object.assign({mergedClsPrefix:o,mergedValue:P,renderedNames:new Set,segmentCapsuleElRef:ge,tabsPaneWrapperRef:G,tabsElRef:c,barElRef:u,addTabInstRef:x,xScrollInstRef:S,scrollWrapperElRef:f,addTabFixed:xe,tabWrapperStyle:k,handleNavResize:Te,mergedSize:b,handleScroll:Ce,handleTabsResize:X,cssVars:l?void 0:w,themeClass:q?.themeClass,animationDirection:he,renderNameListRef:me,yScrollElRef:v,handleSegmentResize:$t,onAnimationBeforeLeave:oe,onAnimationEnter:J,onAnimationAfterEnter:re,onRender:q?.onRender},ke)},render(){const{mergedClsPrefix:e,type:t,placement:r,addTabFixed:n,addable:a,mergedSize:i,renderNameListRef:o,onRender:l,paneWrapperClass:s,paneWrapperStyle:c,$slots:{default:u,prefix:f,suffix:x}}=this;l?.();const S=u?xt(u()).filter(F=>F.type.__TAB_PANE__===!0):[],v=u?xt(u()).filter(F=>F.type.__TAB__===!0):[],m=!v.length,y=t==="card",b=t==="segment",T=!y&&!b&&this.justifyContent;o.value=[];const R=()=>{const F=d("div",{style:this.tabWrapperStyle,class:`${e}-tabs-wrapper`},T?null:d("div",{class:`${e}-tabs-scroll-padding`,style:r==="top"||r==="bottom"?{width:`${this.tabsPadding}px`}:{height:`${this.tabsPadding}px`}}),m?S.map((k,V)=>(o.value.push(k.props.name),Vt(d(Qt,Object.assign({},k.props,{internalCreatedByPane:!0,internalLeftPadded:V!==0&&(!T||T==="center"||T==="start"||T==="end")}),k.children?{default:k.children.tab}:void 0)))):v.map((k,V)=>(o.value.push(k.props.name),Vt(V!==0&&!T?Er(k):k))),!n&&a&&y?Fr(a,(m?S.length:v.length)!==0):null,T?null:d("div",{class:`${e}-tabs-scroll-padding`,style:{width:`${this.tabsPadding}px`}}));return d("div",{ref:"tabsElRef",class:`${e}-tabs-nav-scroll-content`},y&&a?d(At,{onResize:this.handleTabsResize},{default:()=>F}):F,y?d("div",{class:`${e}-tabs-pad`}):null,y?null:d("div",{ref:"barElRef",class:`${e}-tabs-bar`}))},P=b?"top":r;return d("div",{class:[`${e}-tabs`,this.themeClass,`${e}-tabs--${t}-type`,`${e}-tabs--${i}-size`,T&&`${e}-tabs--flex`,`${e}-tabs--${P}`],style:this.cssVars},d("div",{class:[`${e}-tabs-nav--${t}-type`,`${e}-tabs-nav--${P}`,`${e}-tabs-nav`]},Re(f,F=>F&&d("div",{class:`${e}-tabs-nav__prefix`},F)),b?d(At,{onResize:this.handleSegmentResize},{default:()=>d("div",{class:`${e}-tabs-rail`,ref:"tabsElRef"},d("div",{class:`${e}-tabs-capsule`,ref:"segmentCapsuleElRef"},d("div",{class:`${e}-tabs-wrapper`},d("div",{class:`${e}-tabs-tab`}))),m?S.map((F,k)=>(o.value.push(F.props.name),d(Qt,Object.assign({},F.props,{internalCreatedByPane:!0,internalLeftPadded:k!==0}),F.children?{default:F.children.tab}:void 0))):v.map((F,k)=>(o.value.push(F.props.name),k===0?F:Er(F))))}):d(At,{onResize:this.handleNavResize},{default:()=>d("div",{class:`${e}-tabs-nav-scroll-wrapper`,ref:"scrollWrapperElRef"},["top","bottom"].includes(P)?d($a,{ref:"xScrollInstRef",onScroll:this.handleScroll},{default:R}):d("div",{class:`${e}-tabs-nav-y-scroll`,onScroll:this.handleScroll,ref:"yScrollElRef"},R()))}),n&&a&&y?Fr(a,!0):null,Re(x,F=>F&&d("div",{class:`${e}-tabs-nav__suffix`},F))),m&&(this.animated&&(P==="top"||P==="bottom")?d("div",{ref:"tabsPaneWrapperRef",style:c,class:[`${e}-tabs-pane-wrapper`,s]},Tr(S,this.mergedValue,this.renderedNames,this.onAnimationBeforeLeave,this.onAnimationEnter,this.onAnimationAfterEnter,this.animationDirection)):Tr(S,this.mergedValue,this.renderedNames)))}});function Tr(e,t,r,n,a,i,o){const l=[];return e.forEach(s=>{const{name:c,displayDirective:u,"display-directive":f}=s.props,x=v=>u===v||f===v,S=t===c;if(s.key!==void 0&&(s.key=c),S||x("show")||x("show:lazy")&&r.has(c)){r.has(c)||r.add(c);const v=!x("if");l.push(v?er(s,[[Or,S]]):s)}}),o?d(zn,{name:`${o}-transition`,onBeforeLeave:n,onEnter:a,onAfterEnter:i},{default:()=>l}):l}function Fr(e,t){return d(Qt,{ref:"addTabInstRef",key:"__addable",name:"__addable",internalCreatedByPane:!0,internalAddable:!0,internalLeftPadded:t,disabled:typeof e=="object"&&e.disabled})}function Er(e){const t=Pn(e);return t.props?t.props.internalLeftPadded=!0:t.props={internalLeftPadded:!0},t}function Vt(e){return Array.isArray(e.dynamicProps)?e.dynamicProps.includes("internalLeftPadded")||e.dynamicProps.push("internalLeftPadded"):e.dynamicProps=["internalLeftPadded"],e}const _o={class:"flex items-center py-4"},Ao={class:"w-[100px]"},To=te({__name:"providers",setup(e){const t=la(),r=qr(),n=I({get(){const l=[];return t.allProviders.forEach(s=>{s.visible&&s.models.forEach(c=>{l.push(`${s.id}:${c}`)})}),l.includes(r[Tt.DEFAULT_MODEL]??"")&&r[Tt.DEFAULT_MODEL]||null},set(l){r[Tt.DEFAULT_MODEL]=l}}),a=I(()=>t.allProviders.map(l=>({label:l.title||l.name,type:"group",key:l.id,children:l.models.map(s=>({label:s,value:`${l.id}:${s}`,disabled:!l.visible}))})));function i(l,s){const c=t.allProviders.find(f=>f.id===l)?.openAISetting?.baseURL??"",u={openAISetting:hr({baseURL:c,apiKey:s})};(!c||!s)&&(u.visible=!1),t.updateProvider(l,{...u})}function o(l,s){const c=t.allProviders.find(f=>f.id===l)?.openAISetting?.apiKey??"",u={openAISetting:hr({baseURL:s,apiKey:c})};(!s||!c)&&(u.visible=!1),t.updateProvider(l,{...u})}return rr(()=>t.initialize()),(l,s)=>(vt(),sr(Ct,null,[dr("div",_o,[dr("div",Ao,mt(l.$t("settings.providers.defaultModel"))+"： ",1),Z(A(wt),{value:A(n),"onUpdate:value":s[0]||(s[0]=c=>Br(n)?n.value=c:null),options:A(a),clearable:""},null,8,["value","options"])]),Z(A(zi)),Z(A(Ga),null,{default:ae(()=>[(vt(!0),sr(Ct,null,_n(A(t).allProviders,(c,u)=>(vt(),Mr(A(Za),{key:c.name,title:c.title??c.name},{"header-extra":ae(()=>[Z(A(Xr),{value:A(t).allProviders[u].visible,disabled:!A(t).allProviders[u].openAISetting.apiKey||!A(t).allProviders[u].openAISetting.baseURL,"onUpdate:value":f=>A(t).updateProvider(c.id,{visible:f}),onClick:s[1]||(s[1]=An(()=>{},["stop"]))},null,8,["value","disabled","onUpdate:value"])]),default:ae(()=>[Z(A(Lt),{class:"my-2"},{default:ae(()=>[Z(A(pr),null,{default:ae(()=>[Mt(mt(l.$t("settings.providers.apiKey")),1)]),_:1}),Z(A(Rt),{type:"password",value:A(t).allProviders[u].openAISetting?.apiKey??"","onUpdate:value":f=>i(c.id,f)},null,8,["value","onUpdate:value"])]),_:2},1024),Z(A(Lt),{class:"my-2"},{default:ae(()=>[Z(A(pr),null,{default:ae(()=>[Mt(mt(l.$t("settings.providers.apiUrl")),1)]),_:1}),Z(A(Rt),{value:A(t).allProviders[u].openAISetting?.baseURL??"","onUpdate:value":f=>o(c.id,f)},null,8,["value","onUpdate:value"])]),_:2},1024),Z(A(Ei),{value:A(t).allProviders[u].models??[],"onUpdate:value":f=>A(t).updateProvider(c.id,{models:f})},null,8,["value","onUpdate:value"])]),_:2},1032,["title"]))),128))]),_:1})],64))}}),Fo=te({__name:"index",setup(e){sa();const{theme:t,themeOverrides:r}=da(),{locale:n,dateLocale:a}=ca(),{t:i}=Tn(),o=M("basic"),l=qr(),s=[{label:"中文",value:"zh"},{label:"English",value:"en"}],c=I(()=>[{label:i("settings.theme.dark"),value:"dark"},{label:i("settings.theme.light"),value:"light"},{label:i("settings.theme.system"),value:"system"}]),u=I(()=>[{label:i("settings.appearance.fontSizeOptions.10"),value:10},{label:i("settings.appearance.fontSizeOptions.12"),value:12},{label:i("settings.appearance.fontSizeOptions.14"),value:14},{label:i("settings.appearance.fontSizeOptions.16"),value:16},{label:i("settings.appearance.fontSizeOptions.18"),value:18},{label:i("settings.appearance.fontSizeOptions.20"),value:20},{label:i("settings.appearance.fontSizeOptions.24"),value:24}]);function f(){setTimeout(()=>o.value="basic",300)}return(x,S)=>{const v=cr("drag-region"),m=cr("title-bar");return vt(),Mr(A(Fn),{class:"bg-main text-tx-primary h-screen flex flex-col",locale:A(n),"date-locale":A(a),theme:A(t),"theme-overrides":A(r)},{default:ae(()=>[Z(A(ua),null,{default:ae(()=>[Z(m,{"is-maximizable":!1,onClose:f},{default:ae(()=>[Z(v,{class:"p-2 text-[16px]"},{default:ae(()=>[Mt(mt(A(i)("settings.title")),1)]),_:1})]),_:1}),Z(A(ka),{class:"h-full p-4"},{default:ae(()=>[Z(A(Po),{class:"h-full",size:"large",animated:"","default-value":"basic",value:A(o),"onUpdate:value":S[5]||(S[5]=y=>Br(o)?o.value=y:null)},{default:ae(()=>[Z(A(Ar),{name:"basic",tab:A(i)("settings.base")},{default:ae(()=>[Z(A(Bi),{model:A(l)},{default:ae(()=>[Z(A(et),{label:A(i)("settings.theme.label"),path:"themeMode"},{default:ae(()=>[Z(A(wt),{value:A(l).themeMode,"onUpdate:value":S[0]||(S[0]=y=>A(l).themeMode=y),options:A(c)},null,8,["value","options"])]),_:1},8,["label"]),Z(A(et),{label:`${A(i)("settings.theme.primaryColor")}-${A(l).primaryColor}`},{default:ae(()=>[Z(A(Ci),{value:A(l).primaryColor,"onUpdate:value":S[1]||(S[1]=y=>A(l).primaryColor=y),"show-alpha":!1},null,8,["value"])]),_:1},8,["label"]),Z(A(et),{label:A(i)("settings.language.label"),path:"language"},{default:ae(()=>[Z(A(wt),{value:A(l).language,"onUpdate:value":S[2]||(S[2]=y=>A(l).language=y),options:s},null,8,["value"])]),_:1},8,["label"]),Z(A(et),{label:A(i)("settings.appearance.fontSize")},{default:ae(()=>[Z(A(wt),{value:A(l).fontSize,"onUpdate:value":S[3]||(S[3]=y=>A(l).fontSize=y),options:A(u)},null,8,["value","options"])]),_:1},8,["label"]),Z(A(et),{label:A(i)("settings.behavior.minimizeToTray"),path:"minimizeToTray"},{default:ae(()=>[Z(A(Xr),{value:A(l).minimizeToTray,"onUpdate:value":S[4]||(S[4]=y=>A(l).minimizeToTray=y)},null,8,["value"])]),_:1},8,["label"])]),_:1},8,["model"])]),_:1},8,["tab"]),Z(A(Ar),{name:"provider",tab:A(i)("settings.provider.modelConfig")},{default:ae(()=>[Z(To)]),_:1},8,["tab"])]),_:1},8,["value"])]),_:1})]),_:1})]),_:1},8,["locale","date-locale","theme","theme-overrides"])}}});En(Fo).use(On).use(fa()).use(In).component("TitleBar",Vn).component("DragRegion",Bn).mount("#app");
